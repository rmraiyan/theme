<footer class="py-2 text-white" style="background-color: #1E1E1E;" id="footer-content">
    <div class="container">
        <div class="row justify-content-between align-items-center align-items-md-start align-items-lg-center">
            <div class="col-10 col-md-6 col-lg-8 mx-auto mx-md-0 order-md-last text-start">
                <div class="row row-cols-2 row-cols-lg-auto justify-content-end g-2 g-md-3">
<div class="col">
        <?php if ( is_active_sidebar( 'footer-widget-area1' ) ) : ?>
            <div id="footer-widget-area1" class="widget-area for-widget">
                <?php dynamic_sidebar( 'footer-widget-area1' ); ?>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="col">
        <?php if ( is_active_sidebar( 'footer-widget-area2' ) ) : ?>
            <div id="footer-widget-area2" class="widget-area for-widget">
                <?php dynamic_sidebar( 'footer-widget-area2' ); ?>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="col">
        <?php if ( is_active_sidebar( 'footer-widget-area3' ) ) : ?>
            <div id="footer-widget-area3" class="widget-area for-widget">
                <?php dynamic_sidebar( 'footer-widget-area3' ); ?>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="col">
        <?php if ( is_active_sidebar( 'footer-widget-area4' ) ) : ?>
            <div id="footer-widget-area4" class="widget-area for-widget">
                <?php dynamic_sidebar( 'footer-widget-area4' ); ?>
            </div>
        <?php endif; ?>
    </div>

            <div class="col-11 col-md-5 col-lg-4 mx-auto mx-md-0 text-center text-md-start">
                <div class="row">
                    <div class="order-last order-md-first">
                               <a class="navbar-brand py-0" href="<?php echo esc_url(get_theme_mod('logo_url_setting', 'https://www.bkash.com')); ?>">
                                  <?php
                                  $logo_svg_url = get_theme_mod('logo_svg_setting');
                                  if ($logo_svg_url) {
                                      echo '<img src="' . esc_url($logo_svg_url) . '" alt="' . esc_attr__('Logo', 'mytheme') . '" class="" />';
                                  }
                                  ?>
                              </a>
                                  <p class="py-0 py-md-1"><?php echo esc_html(get_theme_mod('footer_content_dec')); ?></p>
                    </div>
                    <div class="py-2 py-md-0">
                        <h5 class="text-white mb-1"><?php echo esc_html(get_theme_mod('footer_content_app_heading')); ?></h5>
                        <div class="d-flex justify-content-center justify-content-md-start">
<?php
                $android_app_image_url = get_theme_mod('android_app_image_setting');
                $android_app_link_url = get_theme_mod('android_app_link_setting');
                if ($android_app_image_url) {
                    echo '
                    
                      
                      <a href="' . esc_url($android_app_link_url) . '" class="me-1 text-white mb-md-1 mb-lg-0" aria-label="Get bKash app on Google Play">';
                    echo '
                      
                        
                        <img src="' . esc_url($android_app_image_url) . '" alt="' . esc_attr__('Android App Image', 'mytheme') . '" />';
                    echo '
                    
                      
                      </a>';
                }
                ?> <?php
                $ios_app_image_url = get_theme_mod('ios_app_image_setting');
                $ios_app_link_url = get_theme_mod('ios_app_link_setting');
                if ($ios_app_image_url) {
                    echo '
                    
                      
                      <a href="' . esc_url($ios_app_link_url) . '" class="text-white" aria-label="Get bKash app on App Store">';
                    echo '
                      
                        
                        <img src="' . esc_url($ios_app_image_url) . '" alt="' . esc_attr__('iOS App Image', 'mytheme') . '" />';
                    echo '
                    
                      
                      </a>';
                }
                ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <hr class="text-white my-1 my-md-2">
        <div class="row justify-content-between align-items-center">
            <div class="col-md order-md-last mb-1 mb-md-0">
                <ul class="list-inline mb-0 text-center text-md-end">
                    <li class="list-inline-item mx-half">
                        <a href="<?php echo esc_html(get_theme_mod('footer_content_facebook')); ?>" target="_blank" class="footer-social-link">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24.645 23.815">
                                <title>Facebook Icon</title>
                                <path fill="#fff" d="M12.327 0a11.914 11.914 0 1 0 12.322 11.907A12.12 12.12 0 0 0 12.327 0Zm3.2 7.186h-1.284c-1.006 0-1.2.462-1.2 1.139v1.494h2.4l-.316 2.343h-2.084v6.01h-2.5v-6.01H8.45V9.821h2.091V8.095a2.869 2.869 0 0 1 3.116-3.094 17.725 17.725 0 0 1 1.869.092Z"></path>
                            </svg>
                        </a>
                    </li>
                    <li class="list-inline-item mx-half">
                        <a href="<?php echo esc_html(get_theme_mod('footer_content_youtube')); ?>" target="_blank" class="footer-social-link">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24.645 23.815">
                                <title>Youtube Icon</title>
                                <path fill="#fff" d="M12.322 0a11.914 11.914 0 1 0 12.323 11.907A12.12 12.12 0 0 0 12.322 0Zm5.76 12.4a16.413 16.413 0 0 1-.116 1.814 2.379 2.379 0 0 1-.461 1.113 1.692 1.692 0 0 1-1.163.475c-1.623.113-4.061.117-4.061.117s-3.016-.027-3.944-.113a2.008 2.008 0 0 1-1.279-.479 2.377 2.377 0 0 1-.461-1.113 16.375 16.375 0 0 1-.116-1.814v-.851a16.367 16.367 0 0 1 .116-1.814 2.376 2.376 0 0 1 .461-1.113 1.692 1.692 0 0 1 1.162-.475c1.624-.113 4.059-.113 4.059-.113h.005s2.435 0 4.059.113a1.692 1.692 0 0 1 1.163.475 2.378 2.378 0 0 1 .461 1.113 16.406 16.406 0 0 1 .116 1.814Z"></path>
                                <path fill="#fff" d="m11.083 13.488 3.135-1.624-3.135-1.636Z"></path>
                            </svg>

                        </a>
                    </li>
                    <li class="list-inline-item mx-half">
                        <a href="<?php echo esc_html(get_theme_mod('footer_content_instagram')); ?>" target="_blank" class="footer-social-link">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24.83 24">
                                <title>Instagram Icon</title>
                                <path fill="#fff" d="M18.082 7.698a2.42 2.42 0 0 0-1.389-1.381 4.065 4.065 0 0 0-1.359-.251c-.772-.035-1-.043-2.958-.043s-2.186.008-2.958.043a4.063 4.063 0 0 0-1.359.251 2.42 2.42 0 0 0-1.394 1.381 4.012 4.012 0 0 0-.252 1.351c-.035.768-.043 1-.043 2.941s.008 2.173.043 2.94a4.012 4.012 0 0 0 .252 1.352 2.42 2.42 0 0 0 1.389 1.381 4.056 4.056 0 0 0 1.359.251c.772.035 1 .043 2.958.043s2.186-.008 2.958-.043a4.058 4.058 0 0 0 1.359-.251 2.42 2.42 0 0 0 1.389-1.381 4.02 4.02 0 0 0 .252-1.351c.035-.767.043-1 .043-2.94s-.007-2.173-.043-2.941a4.02 4.02 0 0 0-.247-1.352Zm-5.706 8.029a3.737 3.737 0 1 1 3.758-3.737 3.748 3.748 0 0 1-3.758 3.737Zm3.907-6.748a.873.873 0 1 1 .878-.873.876.876 0 0 1-.879.873Z"></path>
                                <path fill="#fff" d="M12.376 9.564a2.426 2.426 0 1 0 2.44 2.426 2.433 2.433 0 0 0-2.44-2.426Z"></path>
                                <path fill="#fff" d="M12.415 0A12.007 12.007 0 1 0 24.83 12 12.213 12.213 0 0 0 12.415 0Zm7.235 14.89a4.981 4.981 0 0 1-.34 1.707 3.434 3.434 0 0 1-.844 1.246 3.607 3.607 0 0 1-1.3.811 5.564 5.564 0 0 1-1.777.327c-.781.034-1.03.042-3.018.042s-2.237-.008-3.018-.042a5.559 5.559 0 0 1-1.777-.327 3.6 3.6 0 0 1-1.3-.811 3.438 3.438 0 0 1-.844-1.246 4.981 4.981 0 0 1-.34-1.707c-.036-.75-.044-.99-.044-2.9s.009-2.15.044-2.9a4.981 4.981 0 0 1 .34-1.707 3.436 3.436 0 0 1 .844-1.246 3.6 3.6 0 0 1 1.3-.811 5.55 5.55 0 0 1 1.777-.327c.781-.034 1.03-.042 3.018-.042s2.237.008 3.018.042a5.555 5.555 0 0 1 1.777.327 3.61 3.61 0 0 1 1.3.811 3.432 3.432 0 0 1 .844 1.246 4.981 4.981 0 0 1 .34 1.707c.036.75.044.99.044 2.9s-.008 2.149-.042 2.9Z"></path>
                            </svg>
                        </a>
                    </li>
                    <li class="list-inline-item mx-half">
                        <a href="<?php echo esc_html(get_theme_mod('footer_content_linkedin')); ?>" target="_blank" class="footer-social-link">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24.748 23.918">
                                <title>Linkedin Icon</title>
                                <path fill="#fff" d="M12.374 0a11.966 11.966 0 1 0 12.374 11.959A12.172 12.172 0 0 0 12.374 0Zm-3.1 17.618H6.65V9.465h2.624ZM7.963 8.353a1.47 1.47 0 1 1 1.519-1.47 1.495 1.495 0 0 1-1.514 1.47Zm11.126 9.265h-2.618v-3.963c0-.945-.019-2.162-1.363-2.162-1.364 0-1.572 1.03-1.572 2.093v4.032h-2.612V9.465h2.512v1.113h.036a2.773 2.773 0 0 1 2.48-1.316c2.652 0 3.142 1.687 3.142 3.883Z"></path>
                            </svg>
                        </a>
                    </li>
                    <li class="list-inline-item mx-half me-md-0">
                        <a href="<?php echo esc_html(get_theme_mod('footer_content_twitter')); ?>" target="_blank" class="footer-social-link">
                            <svg width="32" height="32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 31.87 31.87">
                                <title>Twitter Icon</title>
                                <circle fill="#fff" cx="15.94" cy="15.94" r="15.94"></circle>
                                <path fill="#000" d="m22.96,22.62l-5.5-7.99,6.1-7.09h-1.39l-1.19,1.38-4.13,4.81-3.93-5.71-.33-.47h-4.83l1.18,1.71,5.23,7.6-6.43,7.48h1.39l5.65-6.58,4.2,6.11.33.47h4.83l-1.18-1.71Zm-3.08.62l-4.37-6.34-.62-.9-5.07-7.36h2.18l4.1,5.95.62.9,5.33,7.75h-2.18Z"></path>
                            </svg>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="col">
                <p class="mb-0 text-center text-md-start small">
                    
                    <?php echo esc_html(get_theme_mod('footer_content_copyright')); ?>
                </p>
            </div>
        </div>
    </div>


    <script>
              function isTouchDevice() {
                return (('ontouchstart' in window) || (navigator.maxTouchPoints > 0) || (navigator.msMaxTouchPoints > 0));
              }

              function enableCarouselCustomControl(carouselElement) {
                const carouselInstance = new bootstrap.Carousel(carouselElement, {
                  touch: isTouchDevice(),
                  pause: !isTouchDevice() && 'hover',
                });

                if (!isTouchDevice()) {
                  carouselElement.classList.add('carousel-fade');
                }

                const pause = carouselElement.querySelector('[data-bs-slide="pause"]');
                const play = carouselElement.querySelector('[data-bs-slide="play"]');
                const prev = carouselElement.querySelector('[data-bs-slide="prev"]');
                const next = carouselElement.querySelector('[data-bs-slide="next"]');

                pause?.addEventListener('click', () => {
                  carouselInstance.pause();
                  pause.classList.toggle('d-none');
                  play.classList.toggle('d-none');
                });

                play?.addEventListener('click', () => {
                  carouselInstance.cycle();
                  pause.classList.toggle('d-none');
                  play.classList.toggle('d-none');
                });

                prev?.addEventListener('click', () => {
                  carouselInstance.prev();
                });

                next?.addEventListener('click', () => {
                  carouselInstance.next();
                });
              }

              document.addEventListener('DOMContentLoaded', () => {
                const bannerCarousel = document.getElementById('bannerCarouselControls');
                if (bannerCarousel) {
                  enableCarouselCustomControl(bannerCarousel);
                }
              });
            </script>


<script>
      const buttons = document.querySelectorAll('.lang-switcher');

      function changeLocale(e) {
        const button = e.currentTarget;
        const defaultLocale = "bn";
        const alternateLocale = defaultLocale === 'en' ? 'bn' : 'en';
        const currentLocal = "bn";
        const {origin, pathname, search} = location;

        if (button.classList.contains(`lang-switcher-${defaultLocale}`) && (pathname.startsWith(`/${alternateLocale}/`) || pathname ===`/${alternateLocale}`)) {
          if (currentLocal === defaultLocale) {
            e.preventDefault();
          }
          location.href = origin + pathname.slice(3) + search;
        }

        if (button.classList.contains(`lang-switcher-${alternateLocale}`)) {
          if (currentLocal === alternateLocale) {
            e.preventDefault();
          }
          if (pathname.startsWith(`/${defaultLocale}/`)) {
            location.href = origin + '/' + alternateLocale + pathname.slice(3) + search;
          } else if (!(pathname.startsWith(`/${alternateLocale}/`) || pathname === `/${alternateLocale}`)) {
            location.href = origin + '/' + alternateLocale + pathname + search;
          }
        }
      }

      buttons.forEach(button => {
        button.addEventListener('click', changeLocale)
      })
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js" id="slickCDN"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js" id="aosCDN"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/11.0.5/swiper-bundle.min.js" id="swiperCDN"></script>

    
<script>
    document.addEventListener("DOMContentLoaded", function (event) {
        let dropdownToggleList = document.querySelectorAll('a.nav-link.dropdown-toggle');
        for (let i = 0; i < dropdownToggleList.length; i++) {
            dropdownToggleList[i].addEventListener('click', (e) => {
                location.href = e.target.href;
            });
        }

        let aosAvailable = document.body.querySelector('[data-aos]')

        if ((aosAvailable !== 0) && (aosAvailable !== null)) {
            AOS.init({
                disable: 'mobile',
                once: true,
            });
        }
    });
</script>


<script>
  jQuery(document).ready(function($) {
    $('.services-slick-slider').slick({
      slidesToShow: 7,
      slidesToScroll: 1,
      responsive: [
        {
          breakpoint: 1025,
          settings: {
            slidesToShow: 5
          }
        },
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 4
          }
        },
        {
          breakpoint: 577,
          settings: {
            slidesToShow: 3
          }
        },
        {
          breakpoint: 0,
          settings: {
            slidesToShow: 1
          }
        }
      ],
      prevArrow: '<button class="slick-prev slick-arrow" style=""><span class="visually-hidden">Left Arrow</span><i class="bi bi-chevron-left"></i></button>',
      nextArrow: '<button class="slick-next slick-arrow" style=""><span class="visually-hidden">Right Arrow</span><i class="bi bi-chevron-right"></i></button>'
    });
  });
</script>


<script>
    document.addEventListener('DOMContentLoaded', function () {
        const duration = 5000; // 5000 milliseconds (5 seconds)
        let activeIndex = 0;
        const textItems = document.querySelectorAll('.box-carousel-nav');
        const imageItems = document.querySelectorAll('.box-slides');

        function updateCarousel() {
            textItems.forEach(item => item.classList.remove('active'));
            imageItems.forEach(item => item.classList.remove('active'));

            textItems[activeIndex].classList.add('active');
            imageItems[activeIndex].classList.add('active');
        }

        function nextSlide() {
            activeIndex = (activeIndex + 1) % textItems.length;
            updateCarousel();
        }

        setInterval(nextSlide, duration);
    });
</script>

</footer>

