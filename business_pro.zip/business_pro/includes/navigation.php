<?php

function register_my_menu() {
  register_nav_menu('primary-menu', __( 'Primary Menu' ));
}
add_action( 'init', 'register_my_menu' );





// Add custom fields to menu item
function my_custom_menu_item_fields($item_id, $item, $depth, $args) {
  $icon_url = get_post_meta($item_id, '_menu_item_icon_url', true);
  ?>
  <p class="field-icon-url description description-wide">
    <label for="edit-menu-item-icon-url-<?php echo $item_id; ?>">
      <?php _e('Icon URL'); ?><br>
      <input type="text" id="edit-menu-item-icon-url-<?php echo $item_id; ?>" class="widefat code edit-menu-item-custom" name="menu-item-icon-url[<?php echo $item_id; ?>]" value="<?php echo esc_attr($icon_url); ?>" />
    </label>
  </p>
  <?php
}
add_action('wp_nav_menu_item_custom_fields', 'my_custom_menu_item_fields', 10, 4);

// Save custom fields
function my_update_menu_item($menu_id, $menu_item_db_id) {
  if (isset($_POST['menu-item-icon-url'][$menu_item_db_id])) {
    $sanitized_data = sanitize_text_field($_POST['menu-item-icon-url'][$menu_item_db_id]);
    update_post_meta($menu_item_db_id, '_menu_item_icon_url', $sanitized_data);
  } else {
    delete_post_meta($menu_item_db_id, '_menu_item_icon_url');
  }
}
add_action('wp_update_nav_menu_item', 'my_update_menu_item', 10, 2);


function add_custom_icons_to_menu($item_output, $item, $depth, $args) {
  $icon_url = get_post_meta($item->ID, '_menu_item_icon_url', true);
  if ($icon_url) {
    $icon = '<img src="' . esc_url($icon_url) . '" alt="" class="menu-icon" /> ';
    $item_output = $args->before . $icon . $args->link_before . $item->title . $args->link_after . $args->after;
  }
  return $item_output;
}
add_filter('walker_nav_menu_start_el', 'add_custom_icons_to_menu', 10, 4);


