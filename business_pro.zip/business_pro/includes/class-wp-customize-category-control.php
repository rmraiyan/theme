<?php
if (class_exists('WP_Customize_Control')) {
    class WP_Customize_Category_Control extends WP_Customize_Control {
        public $type = 'dropdown-categories';

        public function render_content() {
            $categories = get_categories();
            ?>
            <label>
                <span class="customize-control-title"><?php echo esc_html($this->label); ?></span>
                <select <?php $this->link(); ?>>
                    <option value=""><?php _e('Select Category'); ?></option>
                    <?php
                    foreach ($categories as $category) {
                        printf('<option value="%s" %s>%s</option>', $category->term_id, selected($this->value(), $category->term_id, false), $category->name);
                    }
                    ?>
                </select>
            </label>
            <?php
        }
    }
}
