<?php

//<!-- Intro Slider: Starts -->
    // Register Custom Post Type
    function create_intro_slider_post_type()
    {
        register_post_type("intro_slider", [
            "labels" => [
                "name" => __("Intro Sliders"),
                "singular_name" => __("Intro Slider"),
            ],
            "public" => true,
            "has_archive" => true,
            "rewrite" => ["slug" => "intro_slider"],
            "supports" => ["title", "thumbnail"],
        ]);
    }
    add_action("init", "create_intro_slider_post_type");

    // Add Custom Fields (Meta Boxes) for Slider Link and Mobile Image
    function add_intro_slider_meta_boxes()
    {
        add_meta_box(
            "intro_slider_link",
            __("Slider Link"),
            "render_intro_slider_link_meta_box",
            "intro_slider",
            "side",
            "default"
        );
        add_meta_box(
            "intro_slider_mobile_image",
            __("Mobile Image"),
            "render_intro_slider_mobile_image_meta_box",
            "intro_slider",
            "side",
            "default"
        );
    }
    add_action("add_meta_boxes", "add_intro_slider_meta_boxes");

    // Render the Slider Link Meta Box
    function render_intro_slider_link_meta_box($post)
    {
        $value = get_post_meta($post->ID, "_intro_slider_link", true);
        echo '<label for="intro_slider_link">' .
            __("Enter the slider link:") .
            "</label>";
        echo '<input type="url" id="intro_slider_link" name="intro_slider_link" value="' .
            esc_attr($value) .
            '" size="25" />';
    }

    // Render the Mobile Image Meta Box
    function render_intro_slider_mobile_image_meta_box($post)
    {
        $image_id = get_post_meta($post->ID, "_intro_slider_mobile_image", true);
        $image_url = $image_id
            ? wp_get_attachment_image_url($image_id, "thumbnail")
            : "";
        echo '<label for="intro_slider_mobile_image">' .
            __("Select a mobile image:") .
            "</label>";
        echo '<input type="hidden" id="intro_slider_mobile_image" name="intro_slider_mobile_image" value="' .
            esc_attr($image_id) .
            '" />';
        echo '<button class="button upload-image-button">' .
            __("Upload Image") .
            "</button>";
        echo '<div class="mobile-image-preview">' .
            ($image_url
                ? '<img src="' .
                    esc_url($image_url) .
                    '" alt="" style="max-width:100%;"/>'
                : "") .
            "</div>";
    }

    // Save Meta Box Data
    function save_intro_slider_meta_boxes($post_id)
    {
        if (array_key_exists("intro_slider_link", $_POST)) {
            update_post_meta(
                $post_id,
                "_intro_slider_link",
                sanitize_text_field($_POST["intro_slider_link"])
            );
        }

        if (array_key_exists("intro_slider_mobile_image", $_POST)) {
            update_post_meta(
                $post_id,
                "_intro_slider_mobile_image",
                intval($_POST["intro_slider_mobile_image"])
            );
        }
    }
    add_action("save_post", "save_intro_slider_meta_boxes");

//<!-- Intro Slider: End -->

//<!-- Service Slider: Starts -->
    // Register Custom Post Type
    function create_service_slider_post_type()
    {
        register_post_type("service_slider", [
            "labels" => [
                "name" => __("Service Sliders"),
                "singular_name" => __("Service Slider"),
            ],
            "public" => true,
            "has_archive" => true,
            "rewrite" => ["slug" => "service_slider"],
            "supports" => ["title", "thumbnail"],
        ]);
    }
    add_action("init", "create_service_slider_post_type");

    // Add custom meta box for slider link
    function add_service_slider_meta_boxes()
    {
        add_meta_box(
            "service_slider_link",
            "Slider Link",
            "render_service_slider_link_meta_box",
            "service_slider",
            "side",
            "default"
        );
    }
    add_action("add_meta_boxes", "add_service_slider_meta_boxes");

    function render_service_slider_link_meta_box($post)
    {
        $slider_link = get_post_meta($post->ID, "_service_slider_link", true); ?>
        <label for="service_slider_link">Link:</label>
        <input type="text" id="service_slider_link" name="service_slider_link" value="<?php echo esc_attr(
            $slider_link
        ); ?>" style="width: 100%;" />
        <?php
    }

    function save_service_slider_meta_box_data($post_id)
    {
        if (array_key_exists("service_slider_link", $_POST)) {
            update_post_meta(
                $post_id,
                "_service_slider_link", // Ensure this matches the meta key used in rendering
                sanitize_text_field($_POST["service_slider_link"])
            );
        }
    }

    add_action("save_post", "save_service_slider_meta_box_data");

//<!-- Service Slider: End -->

//<!-- Services Card: Starts -->
    function create_services_card_post_type()
    {
        register_post_type("services_card", [
            "labels" => [
                "name" => __("Services Cards"),
                "singular_name" => __("Services Card"),
            ],
            "public" => true,
            "has_archive" => true,
            "rewrite" => ["slug" => "services_card"],
            "supports" => ["title", "editor", "thumbnail"],
        ]);
    }
    add_action("init", "create_services_card_post_type");

    function add_services_card_meta_boxes()
    {
        add_meta_box(
            "services_card_link",
            "Card Link",
            "render_services_card_link_meta_box",
            "services_card",
            "side",
            "default"
        );
    }
    add_action("add_meta_boxes", "add_services_card_meta_boxes");

    function render_services_card_link_meta_box($post)
    {
        $card_link = get_post_meta($post->ID, "_services_card_link", true); ?>
        <label for="services_card_link">Link:</label>
        <input type="text" id="services_card_link" name="services_card_link" value="<?php echo esc_attr(
            $card_link
        ); ?>" style="width: 100%;" />
        <?php
    }

    function save_services_card_meta_box_data($post_id)
    {
        if (array_key_exists("services_card_link", $_POST)) {
            update_post_meta(
                $post_id,
                "_services_card_link",
                sanitize_text_field($_POST["services_card_link"])
            );
        }
    }
    add_action("save_post", "save_services_card_meta_box_data");

//<!-- Services Card: End -->

// <!-- Business Cards: Starts -->
    // Register Custom Post Type
    function create_business_card_post_type() {
        register_post_type('business_card',
            array(
                'labels' => array(
                    'name' => __('Business Cards'),
                    'singular_name' => __('Business Card'),
                ),
                'public' => true,
                'has_archive' => true,
                'rewrite' => array('slug' => 'business_card'),
                'supports' => array('title', 'thumbnail'),
            )
        );
    }
    add_action('init', 'create_business_card_post_type');

    // Add custom meta box for the link field
    function add_business_card_meta_boxes() {
        add_meta_box(
            'business_card_link',
            'Card Link',
            'render_business_card_link_meta_box',
            'business_card',
            'side',
            'default'
        );
    }
    add_action('add_meta_boxes', 'add_business_card_meta_boxes');

    function render_business_card_link_meta_box($post) {
        $card_link = get_post_meta($post->ID, '_business_card_link', true);
        ?>
        <label for="business_card_link">Link:</label>
        <input type="text" id="business_card_link" name="business_card_link" value="<?php echo esc_attr($card_link); ?>" style="width: 100%;" />
        <?php
    }

    function save_business_card_meta_box_data($post_id) {
        if (array_key_exists('business_card_link', $_POST)) {
            update_post_meta(
                $post_id,
                '_business_card_link',
                sanitize_text_field($_POST['business_card_link'])
            );
        }
    }
    add_action('save_post', 'save_business_card_meta_box_data');
// <!-- Business Cards: End -->

// <!-- bKash Locator: Starts -->
    // Register Custom Post Type
    function create_bkash_locator_post_type() {
        register_post_type('bkash_locator',
            array(
                'labels' => array(
                    'name' => __('bKash Locator'),
                    'singular_name' => __('bKash Locator'),
                ),
                'public' => true,
                'has_archive' => true,
                'rewrite' => array('slug' => 'bkash_locator'),
                'supports' => array('title', 'editor', 'thumbnail'),
            )
        );
    }
    add_action('init', 'create_bkash_locator_post_type');
//<!-- bKash Locator: End -->

//<!-- Offer Section: Starts-->
    // Register Custom Post Type
    function create_offer_section_post_type() {
        register_post_type('offer_section',
            array(
                'labels' => array(
                    'name' => __('Offer Section'),
                    'singular_name' => __('Offer Section'),
                ),
                'public' => true,
                'has_archive' => true,
                'rewrite' => array('slug' => 'offer_section'),
                'supports' => array('title', 'editor', 'thumbnail'),
            )
        );
    }
    add_action('init', 'create_offer_section_post_type');
//<!-- Offer Section: End-->

// Register Custom Post Type for Box Carousel
function create_box_carousel_post_type() {
    register_post_type('box_carousel',
        array(
            'labels' => array(
                'name' => __('Box Carousels'),
                'singular_name' => __('Box Carousel'),
            ),
            'public' => true,
            'has_archive' => true,
            'supports' => array('title', 'editor', 'thumbnail'),
            'rewrite' => array('slug' => 'box_carousel'),
        )
    );
}
add_action('init', 'create_box_carousel_post_type');


// Add the Meta Box
function add_minute_read_meta_box() {
    add_meta_box(
        'minute_read_meta_box', // ID
        'Minute Read', // Title
        'display_minute_read_meta_box', // Callback function
        'post', // Post type
        'side', // Context (where the meta box appears)
        'default' // Priority
    );
}
add_action('add_meta_boxes', 'add_minute_read_meta_box');

// Display the Meta Box
function display_minute_read_meta_box($post) {
    $minute_read = get_post_meta($post->ID, '_minute_read', true);
    wp_nonce_field('save_minute_read_meta_box_data', 'minute_read_meta_box_nonce');
    ?>
    <label for="minute_read">Minute Read:</label>
    <input type="text" name="minute_read" id="minute_read" value="<?php echo esc_attr($minute_read); ?>" />
    <?php
}

// Save the Meta Box Data
function save_minute_read_meta_box($post_id) {
    // Check if our nonce is set and verify it.
    if (!isset($_POST['minute_read_meta_box_nonce']) || !wp_verify_nonce($_POST['minute_read_meta_box_nonce'], 'save_minute_read_meta_box_data')) {
        return;
    }

    // Verify if this is an auto save routine.
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Sanitize user input.
    $minute_read = sanitize_text_field($_POST['minute_read']);

    // Update the meta field in the database.
    update_post_meta($post_id, '_minute_read', $minute_read);
}
add_action('save_post', 'save_minute_read_meta_box');

// Display "Minute Read" in Post Content (Optional)
function display_minute_read_in_content($content) {
    if (is_singular('post')) {
        $minute_read = get_post_meta(get_the_ID(), '_minute_read', true);
        if ($minute_read) {
            $minute_read_content = '<p>Estimated Reading Time: ' . esc_html($minute_read) . ' minute(s)</p>';
            $content = $minute_read_content . $content;
        }
    }
    return $content;
}
add_filter('the_content', 'display_minute_read_in_content');




function create_director_post_type() {
    register_post_type('director',
        array(
            'labels' => array(
                'name' => __('Directors'),
                'singular_name' => __('Director'),
            ),
            'public' => true,
            'has_archive' => true,
            'supports' => array('title', 'editor', 'thumbnail'),
            'menu_icon' => 'dashicons-admin-users', // Optional icon
            'show_in_rest' => true, // Enable Gutenberg editor
        )
    );
}
add_action('init', 'create_director_post_type');

// Add custom meta box for the title
function add_director_meta_box() {
    add_meta_box(
        'director_title_meta_box', // Unique ID
        'Custom Title', // Box title
        'display_director_meta_box', // Content callback
        'director', // Post type
        'normal', // Context
        'high' // Priority
    );
}
add_action('add_meta_boxes', 'add_director_meta_box');

// Display the custom meta box
function display_director_meta_box($post) {
    // Retrieve existing value from the database
    $custom_title = get_post_meta($post->ID, 'custom_title', true);
    // Add nonce for security
    wp_nonce_field('save_director_meta_box_data', 'director_meta_box_nonce');
    ?>
    <label for="custom_title">Custom Title:</label>
    <input type="text" name="custom_title" id="custom_title" value="<?php echo esc_attr($custom_title); ?>" style="width: 100%;" />
    <?php
}

// Save custom meta box data
function save_director_meta_box_data($post_id) {
    // Check if our nonce is set.
    if (!isset($_POST['director_meta_box_nonce'])) {
        return $post_id;
    }
    $nonce = $_POST['director_meta_box_nonce'];

    // Verify that the nonce is valid.
    if (!wp_verify_nonce($nonce, 'save_director_meta_box_data')) {
        return $post_id;
    }

    // Check if this is an autosave.
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }

    // Check the user's permissions.
    if ('director' === $_POST['post_type']) {
        if (!current_user_can('edit_post', $post_id)) {
            return $post_id;
        }
    }

    // Sanitize and save the custom title.
    $custom_title = sanitize_text_field($_POST['custom_title']);
    update_post_meta($post_id, 'custom_title', $custom_title);
}
add_action('save_post', 'save_director_meta_box_data');


function create_brand_post_type() {
    register_post_type('brand',
        array(
            'labels' => array(
                'name' => __('Brands'),
                'singular_name' => __('Brand'),
            ),
            'public' => true,
            'has_archive' => true,
            'supports' => array('title', 'thumbnail'), // Only title and thumbnail are supported
            'menu_icon' => 'dashicons-admin-site', // Optional icon
            'show_in_rest' => true, // Enable Gutenberg editor
        )
    );
}
add_action('init', 'create_brand_post_type');
