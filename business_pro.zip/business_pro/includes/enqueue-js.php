<?php
function enqueue_slick_slider_assets() {
    // Enqueue Slick Slider CSS
    wp_enqueue_style('slick-css', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css');
    wp_enqueue_style('slick-theme-css', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css');

    // Enqueue Slick Slider JS
    wp_enqueue_script('slick-js', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js', array('jquery'), null, true);

}
add_action('wp_enqueue_scripts', 'enqueue_slick_slider_assets');



function enqueue_my_scripts() {
    // Enqueue jQuery
      wp_enqueue_script('jquery');
    // Enqueue Bootstrap JS
    wp_enqueue_script('bootstrap-js', get_template_directory_uri() . '/assets/lib/bootstrap/js/bootstrap.bundle.min.js', array('jquery'), '5.1.3', false);

    // Enqueue AOS JS
    wp_enqueue_script('aos-js', get_template_directory_uri() . '/assets/lib/aos/aos.js', array(), '2.3.4', false);

    // Enqueue Swiper JS
    wp_enqueue_script('swiper-js', get_template_directory_uri() . '/assets/lib/swiper/swiper-bundle.min.js', array(), '7.0.0', false);
    // Enqueue slick JS
    wp_enqueue_script('slick-js', get_template_directory_uri() . '/assets/lib/slick-carousel/1.9.0/slick.min.js');

    // Enqueue Purecounter JS
    wp_enqueue_script('purecounter-js', get_template_directory_uri() . '/assets/lib/purecounter/purecounter.js', array(), '1.0.0', false);

    // Enqueue GLightbox JS
    wp_enqueue_script('glightbox-js', get_template_directory_uri() . '/assets/lib/glightbox/js/glightbox.min.js', array(), '1.2.3', false);

    // Enqueue Website JS
    wp_enqueue_script('website-js', get_template_directory_uri() . '/js/website.js', array('jquery'), '1.0.0', true);
    // Enqueue Custom JS
    wp_enqueue_script('custom-js', get_template_directory_uri() . '/js/custom.js', array('jquery'), '1.0.0', true);

}

add_action('wp_enqueue_scripts', 'enqueue_my_scripts');