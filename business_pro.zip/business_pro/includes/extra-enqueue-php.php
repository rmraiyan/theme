<?php
// Enqueue the media uploader for mobile image
function intro_slider_enqueue_scripts($hook) {
    if ($hook === 'post.php' || $hook === 'post-new.php') {
        wp_enqueue_media();
        wp_enqueue_script('intro-slider-custom-js', get_template_directory_uri() . '/js/intro-slider.js', array('jquery'), null, true);
    }
}
add_action('admin_enqueue_scripts', 'intro_slider_enqueue_scripts');



// In functions.php
function convert_to_bangla_date($english_date) {
    $eng_to_ban_num = array(0 => '০', 1 => '১', 2 => '২', 3 => '৩', 4 => '৪', 5 => '৫', 6 => '৬', 7 => '৭', 8 => '৮', 9 => '৯');
    return str_replace(array_keys($eng_to_ban_num), $eng_to_ban_num, $english_date);
}


// Add theme support
function your_theme_setup() {
    // Add support for post thumbnails/featured images
    add_theme_support('post-thumbnails');

    // Add support for automatic title tag
    add_theme_support('title-tag');

    // Add support for HTML5 elements
    add_theme_support('html5', array('comment-list', 'comment-form', 'search-form', 'gallery', 'caption'));
}
add_action('after_setup_theme', 'your_theme_setup');



function enable_svg_uploads($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'enable_svg_uploads');


function add_custom_upload_mimes( $mimes_types ) {
    $mimes_types['webp'] = 'image/webp'; // webp files
    return $mimes_types;
}
add_filter( 'upload_mimes', 'add_custom_upload_mimes' );

function add_allow_upload_extension_exception( $types, $file, $filename, $mimes ) {
    // Do basic extension validation and MIME mapping
      $wp_filetype = wp_check_filetype( $filename, $mimes );
      $ext         = $wp_filetype['ext'];
      $type        = $wp_filetype['type'];
    if( in_array( $ext, array( 'webp' ) ) ) { // if follows webp files have
      $types['ext'] = $ext;
      $types['type'] = $type;
    }
    return $types;
}
add_filter( 'wp_check_filetype_and_ext', 'add_allow_upload_extension_exception', 99, 4 );
  


function displayable_image_webp( $result, $path ) {
    if ($result === false) {
        $displayable_image_types = array( IMAGETYPE_WEBP );
        $info = @getimagesize( $path );

        if (empty($info)) {
            $result = false;
        } elseif (!in_array($info[2], $displayable_image_types)) {
            $result = false;
        } else {
            $result = true;
        }
    }

    return $result;
}
add_filter( 'file_is_displayable_image', 'displayable_image_webp', 10, 2 );