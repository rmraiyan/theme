<?php

function my_theme_customizer_register($wp_customize) {
    // Add a section for the logo settings
    $wp_customize->add_section('logo_section', array(
        'title' => __('Logo Settings', 'mytheme'),
        'priority' => 30,
    ));

    // Add a setting for the logo URL
    $wp_customize->add_setting('logo_url_setting', array(
        'default' => 'https://www.bkash.com',
        'sanitize_callback' => 'esc_url_raw',
    ));

    // Add a control for the logo URL
    $wp_customize->add_control('logo_url_control', array(
        'label' => __('Logo URL', 'mytheme'),
        'section' => 'logo_section',
        'settings' => 'logo_url_setting',
        'type' => 'url',
    ));

    // Add a setting for the SVG logo
    $wp_customize->add_setting('logo_svg_setting', array(
        'sanitize_callback' => 'esc_url_raw',
    ));

    // Add a control for the SVG logo upload
    $wp_customize->add_control(new WP_Customize_Upload_Control($wp_customize, 'logo_svg_control', array(
        'label' => __('Logo SVG', 'mytheme'),
        'section' => 'logo_section',
        'settings' => 'logo_svg_setting',
        'mime_type' => 'image/svg+xml',
    )));

    $wp_customize->add_section('header_button_app', array(
    'title' => __('Header Button App', 'mytheme'),
    'priority' => 31,
    ));

    // Add a setting for the button link
    $wp_customize->add_setting('header_button_link_setting', array(
        'default' => 'https://www.bkash.com/app',
        'sanitize_callback' => 'esc_url_raw',
    ));

    // Add a control for the button link
    $wp_customize->add_control('header_button_link_control', array(
        'label' => __('Header Button Link', 'mytheme'),
        'section' => 'header_button_app',
        'settings' => 'header_button_link_setting',
        'type' => 'url',
    ));

    // Add a setting for the button text
    $wp_customize->add_setting('header_button_text_setting', array(
        'default' => 'বিকাশ অ্যাপ',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    // Add a control for the button text
    $wp_customize->add_control('header_button_text_control', array(
        'label' => __('Header Button Text', 'mytheme'),
        'section' => 'header_button_app',
        'settings' => 'header_button_text_setting',
        'type' => 'text',
    ));


//-----
        // Add a setting for the button link
    $wp_customize->add_setting('header_button_link_eng', array(
        'default' => 'https://www.bkash.com/app',
        'sanitize_callback' => 'esc_url_raw',
    ));

    // Add a control for the button link
    $wp_customize->add_control('header_button_link_eng_control', array(
        'label' => __('Header Button ENG Link', 'mytheme'),
        'section' => 'header_button_app',
        'settings' => 'header_button_link_eng',
        'type' => 'url',
    ));

    // Add a setting for the button text
    $wp_customize->add_setting('header_button_text_eng', array(
        'default' => 'ENGt',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    // Add a control for the button text
    $wp_customize->add_control('header_button_text_eng_control', array(
        'label' => __('Header Button ENG Text', 'mytheme'),
        'section' => 'header_button_app',
        'settings' => 'header_button_text_eng',
        'type' => 'text',
    ));

    //--
   
//-----
        // Add a setting for the button link
    $wp_customize->add_setting('header_button_link_bng', array(
        'default' => 'https://www.bkash.com/app',
        'sanitize_callback' => 'esc_url_raw',
    ));

    // Add a control for the button link
    $wp_customize->add_control('header_button_link_bng_control', array(
        'label' => __('Header Button bng Link', 'mytheme'),
        'section' => 'header_button_app',
        'settings' => 'header_button_link_eng',
        'type' => 'url',
    ));

    // Add a setting for the button text
    $wp_customize->add_setting('header_button_text_bng', array(
        'default' => 'ENGt',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    // Add a control for the button text
    $wp_customize->add_control('header_button_text_bng_control', array(
        'label' => __('Header Button bng Text', 'mytheme'),
        'section' => 'header_button_app',
        'settings' => 'header_button_text_bng',
        'type' => 'text',
    ));

    //--

    // Add a section for the services cards
    $wp_customize->add_section('services_card_section', array(
        'title' => __('Services Cards', 'mytheme'),
        'priority' => 32,
    ));

    // Add a services card text
    $wp_customize->add_setting('services_card_text_setting', array(
        'default' => 'সব আর্থিক সল্যুশন এক প্ল্যাটফর্মে',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    // Add a control for the button text
    $wp_customize->add_control('services_card_text_control', array(
        'label' => __('Services card header text', 'mytheme'),
        'section' => 'services_card_section',
        'settings' => 'services_card_text_setting',
        'type' => 'text',
    ));

    $wp_customize->add_setting('services_title_text_setting', array(
    'default' => 'সব আর্থিক সল্যুশন এক প্ল্যাটফর্মে',
    'sanitize_callback' => 'sanitize_text_field',
    ));

    // Add a control for the button text
    $wp_customize->add_control('services_title_text_control', array(
        'label' => __('Services title header text', 'mytheme'),
        'section' => 'services_card_section',
        'settings' => 'services_title_text_setting',
        'type' => 'text',
    ));



    // Add a section for bkash-app-content
    $wp_customize->add_section('bkash_app_content_section', array(
        'title' => __('bKash App Content', 'mytheme'),
        'priority' => 33,
    ));

    // Add setting and control for background image
    $wp_customize->add_setting('background_image_setting', array(
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'background_image_control', array(
        'label' => __('Background Image', 'mytheme'),
        'section' => 'bkash_app_content_section',
        'settings' => 'background_image_setting',
    )));

    // Add setting and control for static-banner
    $wp_customize->add_setting('static_banner_setting', array(
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'static_banner_control', array(
        'label' => __('Static Banner', 'mytheme'),
        'section' => 'bkash_app_content_section',
        'settings' => 'static_banner_setting',
    )));

    // Add setting and control for Android app image
    $wp_customize->add_setting('android_app_image_setting', array(
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'android_app_image_control', array(
        'label' => __('Android App Image', 'mytheme'),
        'section' => 'bkash_app_content_section',
        'settings' => 'android_app_image_setting',
    )));
    $wp_customize->add_setting('android_app_link_setting', array(
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('android_app_link_control', array(
        'label' => __('Android App Image Link', 'mytheme'),
        'section' => 'bkash_app_content_section',
        'settings' => 'android_app_link_setting',
        'type' => 'url',
    ));

    // Add setting and control for iOS app image
    $wp_customize->add_setting('ios_app_image_setting', array(
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'ios_app_image_control', array(
        'label' => __('iOS App Image', 'mytheme'),
        'section' => 'bkash_app_content_section',
        'settings' => 'ios_app_image_setting',
    )));
    $wp_customize->add_setting('ios_app_link_setting', array(
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('ios_app_link_control', array(
        'label' => __('iOS App Image Link', 'mytheme'),
        'section' => 'bkash_app_content_section',
        'settings' => 'ios_app_link_setting',
        'type' => 'url',
    ));

    // Add setting and control for bkash-app-content Heading
    $wp_customize->add_setting('bkash_app_content_heading_setting', array(
        'default' => __('Default Heading', 'mytheme'),
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('bkash_app_content_heading_control', array(
        'label' => __('bKash App Content Heading', 'mytheme'),
        'section' => 'bkash_app_content_section',
        'settings' => 'bkash_app_content_heading_setting',
        'type' => 'text',
    ));

    // Add setting and control for bkash-app-content Description
    $wp_customize->add_setting('bkash_app_content_description_setting', array(
        'default' => __('Default description', 'mytheme'),
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('bkash_app_content_description_control', array(
        'label' => __('bKash App Content Description', 'mytheme'),
        'section' => 'bkash_app_content_section',
        'settings' => 'bkash_app_content_description_setting',
        'type' => 'textarea',
    ));

    $wp_customize->add_section('business_content_section', array(
    'title' => __('Business Content', 'mytheme'),
    'priority' => 34,
    ));

    // Add setting and control for Heading
    $wp_customize->add_setting('business_content_heading', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('business_content_heading_control', array(
        'label' => __('Heading', 'mytheme'),
        'section' => 'business_content_section',
        'settings' => 'business_content_heading',
        'type' => 'text',
    ));

    // Add setting and control for Description
    $wp_customize->add_setting('business_content_description', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('business_content_description_control', array(
        'label' => __('Description', 'mytheme'),
        'section' => 'business_content_section',
        'settings' => 'business_content_description',
        'type' => 'textarea',
    ));

    // Add setting and control for Banner
    $wp_customize->add_setting('business_content_banner', array(
            'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Upload_Control($wp_customize, 'business_content_banner_control', array(
            'label' => __('Banner Image', 'mytheme'),
            'section' => 'business_content_section',
            'settings' => 'business_content_banner',
            'mime_type' => 'image',
    )));

    $wp_customize->add_section('bKash_blogs_content_section', array(
    'title' => __('bKash Blogs', 'mytheme'),
    'priority' => 35,
    ));

    // Add setting and control for Heading
    $wp_customize->add_setting('bKash_blogs_content_heading', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('bKash_blogs_content_heading_control', array(
        'label' => __('Heading', 'mytheme'),
        'section' => 'bKash_blogs_content_section',
        'settings' => 'bKash_blogs_content_heading',
        'type' => 'text',
    ));

    // Add setting and control for Button
    $wp_customize->add_setting('bKash_blogs_content_button_text', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('bKash_blogs_content_button_control_text', array(
        'label' => __('Button text', 'mytheme'),
        'section' => 'bKash_blogs_content_section',
        'settings' => 'bKash_blogs_content_button_text',
        'type' => 'text',
    ));

    // Add setting and control for Button
    $wp_customize->add_setting('bKash_blogs_content_button', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('bKash_blogs_content_button_control', array(
        'label' => __('Button url', 'mytheme'),
        'section' => 'bKash_blogs_content_section',
        'settings' => 'bKash_blogs_content_button',
        'type' => 'text',
    ));

    $wp_customize->add_section('bkash_locator_content_section', array(
    'title' => __('bkash Locator', 'mytheme'),
    'priority' => 36,
    ));

    // Add setting and control for Heading
    $wp_customize->add_setting('bkash_locator_content_heading', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('bkash_locator_content_heading_control', array(
        'label' => __('Heading', 'mytheme'),
        'section' => 'bkash_locator_content_section',
        'settings' => 'bkash_locator_content_heading',
        'type' => 'text',
    ));

    $wp_customize->add_section('offer_section_content_section', array(
    'title' => __('Offer Section', 'mytheme'),
    'priority' => 37,
    ));

    // Add setting and control for Heading
    $wp_customize->add_setting('offer_section_content_heading', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('offer_section_content_heading_control', array(
        'label' => __('Heading', 'mytheme'),
        'section' => 'offer_section_content_section',
        'settings' => 'offer_section_content_heading',
        'type' => 'text',
    ));
    
    // Add setting and control for Heading
    $wp_customize->add_setting('offer_section_content_dec', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('offer_section_content_dec_control', array(
        'label' => __('Description', 'mytheme'),
        'section' => 'offer_section_content_section',
        'settings' => 'offer_section_content_dec',
        'type' => 'text',
    ));

    // Add setting and control for Heading
    $wp_customize->add_setting('offer_section_content_button_text', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('offer_section_content_button_text_control', array(
        'label' => __('Button text', 'mytheme'),
        'section' => 'offer_section_content_section',
        'settings' => 'offer_section_content_button_text',
        'type' => 'text',
    ));

    // Add setting and control for Heading
    $wp_customize->add_setting('offer_section_content_button_url', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('offer_section_content_button_url_control', array(
        'label' => __('Button url', 'mytheme'),
        'section' => 'offer_section_content_section',
        'settings' => 'offer_section_content_button_url',
        'type' => 'text',
    ));

    $wp_customize->add_section('cubic_carousel_content_section', array(
    'title' => __('Cubic Carousel', 'mytheme'),
    'priority' => 38,
    ));

    // Add setting and control for Heading
    $wp_customize->add_setting('cubic_carousel_content_heading', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cubic_carousel_content_heading_control', array(
        'label' => __('Heading', 'mytheme'),
        'section' => 'cubic_carousel_content_section',
        'settings' => 'cubic_carousel_content_heading',
        'type' => 'text',
    ));

    $wp_customize->add_section('footer_content_section', array(
    'title' => __('Footer Content', 'mytheme'),
    'priority' => 39,
    ));

    // Add setting and control for Heading
    $wp_customize->add_setting('footer_content_dec', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('footer_content_dec_control', array(
        'label' => __('Description', 'mytheme'),
        'section' => 'footer_content_section',
        'settings' => 'footer_content_dec',
        'type' => 'text',
    ));

    // Add setting and control for Heading
    $wp_customize->add_setting('footer_content_app_heading', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('footer_content_heading_control', array(
        'label' => __('App Heading', 'mytheme'),
        'section' => 'footer_content_section',
        'settings' => 'footer_content_app_heading',
        'type' => 'text',
    ));

    // Add setting and control for Heading
    $wp_customize->add_setting('footer_content_copyright', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('footer_content_copyright_control', array(
        'label' => __('copyright text', 'mytheme'),
        'section' => 'footer_content_section',
        'settings' => 'footer_content_copyright',
        'type' => 'text',
    ));

    // Add setting and control for Facebook
    $wp_customize->add_setting('footer_content_facebook', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('footer_content_facebook_control', array(
        'label' => __('Facebook Text', 'mytheme'),
        'section' => 'footer_content_section',
        'settings' => 'footer_content_facebook',
        'type' => 'text',
    ));

    // Add setting and control for YouTube
    $wp_customize->add_setting('footer_content_youtube', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('footer_content_youtube_control', array(
        'label' => __('YouTube Text', 'mytheme'),
        'section' => 'footer_content_section',
        'settings' => 'footer_content_youtube',
        'type' => 'text',
    ));

    // Add setting and control for LinkedIn
    $wp_customize->add_setting('footer_content_linkedin', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('footer_content_linkedin_control', array(
        'label' => __('LinkedIn Text', 'mytheme'),
        'section' => 'footer_content_section',
        'settings' => 'footer_content_linkedin',
        'type' => 'text',
    ));

    // Add setting and control for Instagram
    $wp_customize->add_setting('footer_content_instagram', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('footer_content_instagram_control', array(
        'label' => __('Instagram Text', 'mytheme'),
        'section' => 'footer_content_section',
        'settings' => 'footer_content_instagram',
        'type' => 'text',
    ));

    // Add setting and control for Twitter
    $wp_customize->add_setting('footer_content_twitter', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('footer_content_twitter_control', array(
        'label' => __('Twitter Text', 'mytheme'),
        'section' => 'footer_content_section',
        'settings' => 'footer_content_twitter',
        'type' => 'text',
    ));

     $wp_customize->add_section('blog_banner_section', array(
        'title'    => __('Blog Banner', 'your-theme-textdomain'),
        'priority' => 40,
    ));

    // Add setting for desktop banner image
    $wp_customize->add_setting('blog_banner_desktop_image', array(
        'default'   => 'https://www.bkash.com/images/blog-desktop-banner.webp',
        'transport' => 'refresh',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'blog_banner_desktop_image', array(
        'label'    => __('Desktop Banner Image', 'your-theme-textdomain'),
        'section'  => 'blog_banner_section',
        'settings' => 'blog_banner_desktop_image',
    )));

    // Add setting for mobile banner image
    $wp_customize->add_setting('blog_banner_mobile_image', array(
        'default'   => 'https://www.bkash.com/images/blog-mobile-banner.webp',
        'transport' => 'refresh',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'blog_banner_mobile_image', array(
        'label'    => __('Mobile Banner Image', 'your-theme-textdomain'),
        'section'  => 'blog_banner_section',
        'settings' => 'blog_banner_mobile_image',
    )));

    // Add setting for desktop banner alt text
    $wp_customize->add_setting('blog_banner_desktop_alt', array(
        'default'   => 'bKash Blog',
        'transport' => 'refresh',
    ));
    $wp_customize->add_control('blog_banner_desktop_alt', array(
        'label'    => __('Desktop Banner Alt Text', 'your-theme-textdomain'),
        'section'  => 'blog_banner_section',
        'type'     => 'text',
    ));

    // Add setting for mobile banner alt text
    $wp_customize->add_setting('blog_banner_mobile_alt', array(
        'default'   => 'bKash Blog',
        'transport' => 'refresh',
    ));
    $wp_customize->add_control('blog_banner_mobile_alt', array(
        'label'    => __('Mobile Banner Alt Text', 'your-theme-textdomain'),
        'section'  => 'blog_banner_section',
        'type'     => 'text',
    ));

    // Add setting for banner title
    $wp_customize->add_setting('blog_banner_title', array(
        'default'   => 'বিকাশ ব্লগ',
        'transport' => 'refresh',
    ));
    $wp_customize->add_control('blog_banner_title', array(
        'label'    => __('Banner Title', 'your-theme-textdomain'),
        'section'  => 'blog_banner_section',
        'type'     => 'text',
    ));

    // Add setting for banner subtitle
    $wp_customize->add_setting('blog_banner_subtitle', array(
        'default'   => 'বিকাশ-এর ব্লগ পড়ুন',
        'transport' => 'refresh',
    ));
    $wp_customize->add_control('blog_banner_subtitle', array(
        'label'    => __('Banner Subtitle', 'your-theme-textdomain'),
        'section'  => 'blog_banner_section',
        'type'     => 'text',
    ));


    // Section for Blog Section 2nd
    $wp_customize->add_section('bog_section_2nd', array(
        'title' => __('Blog Section 2nd', 'mytheme'),
        'description' => __('Customize the Blog Section 2nd', 'mytheme'),
        'priority' => 41,
    ));

    // Field for বিকাশ সেবাসমূহ Title
    $wp_customize->add_setting('bkash_services_title', array(
        'default' => __('বিকাশ সেবাসমূহ', 'mytheme'),
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('bkash_services_title', array(
        'label' => __('বিকাশ সেবাসমূহ Title', 'mytheme'),
        'section' => 'bog_section_2nd',
        'type' => 'text',
    ));

    // Field for বিস্তারিত জানুন Button Text
    $wp_customize->add_setting('details_button_text', array(
        'default' => __('বিস্তারিত জানুন', 'mytheme'),
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('details_button_text', array(
        'label' => __('Button Text for বিস্তারিত জানুন', 'mytheme'),
        'section' => 'bog_section_2nd',
        'type' => 'text',
    ));

    // Field for বিস্তারিত জানুন Button Link
    $wp_customize->add_setting('details_button_link', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));

    $wp_customize->add_control('details_button_link', array(
        'label' => __('Link for বিস্তারিত জানুন Button', 'mytheme'),
        'section' => 'bog_section_2nd',
        'type' => 'url',
    ));

    // Dropdown to select Category
    $wp_customize->add_setting('bog_section_2nd_category', array(
        'default' => '',
        'sanitize_callback' => 'absint',
    ));

    $wp_customize->add_control(new WP_Customize_Category_Control($wp_customize, 'bog_section_2nd_category', array(
        'label' => __('Select Category to Display Posts', 'mytheme'),
        'section' => 'bog_section_2nd',
    )));

    // Add a new section for the 3rd blog section
    $wp_customize->add_section('bog_section_3rd', array(
        'title' => __('Bog Section 3rd', 'textdomain'),
        'description' => __('Customize the third blog section.', 'textdomain'),
        'priority' => 42,
    ));

    // Setting for the category dropdown
    $wp_customize->add_setting('bog_section_3rd_category', array(
        'default' => '',
        'sanitize_callback' => 'absint',
    ));

    // Control for the category dropdown
    $wp_customize->add_control(new WP_Customize_Category_Control($wp_customize, 'bog_section_3rd_category', array(
        'label' => __('Select Category', 'textdomain'),
        'section' => 'bog_section_3rd',
        'settings' => 'bog_section_3rd_category',
    )));

    // Setting for the বিস্তারিত জানুন text
    $wp_customize->add_setting('bog_section_3rd_detail_text', array(
        'default' => __('বিস্তারিত জানুন', 'textdomain'),
        'sanitize_callback' => 'sanitize_text_field',
    ));

    // Control for the বিস্তারিত জানুন text
    $wp_customize->add_control('bog_section_3rd_detail_text', array(
        'label' => __('Detail Text', 'textdomain'),
        'section' => 'bog_section_3rd',
        'settings' => 'bog_section_3rd_detail_text',
        'type' => 'text',
    ));

    // Setting for the বিকাশ অ্যাপ text
    $wp_customize->add_setting('bog_section_3rd_app_text', array(
        'default' => __('বিকাশ অ্যাপ', 'textdomain'),
        'sanitize_callback' => 'sanitize_text_field',
    ));

    // Control for the বিকাশ অ্যাপ text
    $wp_customize->add_control('bog_section_3rd_app_text', array(
        'label' => __('App Text', 'textdomain'),
        'section' => 'bog_section_3rd',
        'settings' => 'bog_section_3rd_app_text',
        'type' => 'text',
    ));

    // Setting for the বিস্তারিত জানুন link
    $wp_customize->add_setting('bog_section_3rd_detail_link', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));

    // Control for the বিস্তারিত জানুন link
    $wp_customize->add_control('bog_section_3rd_detail_link', array(
        'label' => __('Detail Link', 'textdomain'),
        'section' => 'bog_section_3rd',
        'settings' => 'bog_section_3rd_detail_link',
        'type' => 'url',
    ));

     // Add Section
    $wp_customize->add_section('featured_video_section', array(
        'title'    => __('Featured Video Section', 'theme-text-domain'),
        'priority' => 43, // This can be made dynamic by changing this value
    ));

    $wp_customize->add_setting('featured_video_id', array(
    'default'           => 'XIkvTKXL2bo',
    'sanitize_callback' => 'sanitize_text_field',
    ));


    $wp_customize->add_control('featured_video_id', array(
        'label'    => __('YouTube Video ID', 'theme-text-domain'),
        'section'  => 'featured_video_section',
        'type'     => 'text',
    ));


    // Add Setting for Banner Image URL
    $wp_customize->add_setting('banner_image_url', array(
        'default'           => 'https://www.bkash.com/images/blog_app_download_banner.webp',
        'sanitize_callback' => 'esc_url_raw',
    ));

    // Add Control for Banner Image URL
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'banner_image_url', array(
        'label'    => __('Banner Image', 'theme-text-domain'),
        'section'  => 'featured_video_section',
        'settings' => 'banner_image_url',
    )));

    // Add Setting for Banner Link URL
    $wp_customize->add_setting('banner_link_url', array(
        'default'           => 'https://www.bkash.com/app',
        'sanitize_callback' => 'esc_url_raw',
    ));

    // Add Control for Banner Link URL
    $wp_customize->add_control('banner_link_url', array(
        'label'    => __('Banner Link URL', 'theme-text-domain'),
        'section'  => 'featured_video_section',
        'type'     => 'url',
    ));

    // Add Setting for Priority
    $wp_customize->add_setting('featured_video_section_priority', array(
        'default'           => 43,
        'sanitize_callback' => 'absint',
    ));

    // Add Control for Priority
    $wp_customize->add_control('featured_video_section_priority', array(
        'label'    => __('Section Priority', 'theme-text-domain'),
        'section'  => 'featured_video_section',
        'type'     => 'number',
    ));

    // Loop to create sections 4th to 11th
    for ($i = 4; $i <= 11; $i++) {
        // Section for bog_section_Xth
        $wp_customize->add_section("bog_section_{$i}th", array(
            'title' => __("BOG Section {$i}th", 'your_textdomain'),
            'priority' => 44,
        ));

        // Text field: বিস্তারিত জানুন
        $wp_customize->add_setting("bog_section_{$i}th_link_text", array(
            'default' => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control("bog_section_{$i}th_link_text", array(
            'label' => __('বিস্তারিত জানুন Text', 'your_textdomain'),
            'section' => "bog_section_{$i}th",
            'type' => 'text',
        ));

        // URL field: বিস্তারিত জানুন Link
        $wp_customize->add_setting("bog_section_{$i}th_link_url", array(
            'default' => '',
            'sanitize_callback' => 'esc_url_raw',
        ));
        $wp_customize->add_control("bog_section_{$i}th_link_url", array(
            'label' => __('বিস্তারিত জানুন Link', 'your_textdomain'),
            'section' => "bog_section_{$i}th",
            'type' => 'url',
        ));

        // Text field: বিকাশ সেবাসমূহ (or other titles)
        $wp_customize->add_setting("bog_section_{$i}th_title", array(
            'default' => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control("bog_section_{$i}th_title", array(
            'label' => __('Section Title', 'your_textdomain'),
            'section' => "bog_section_{$i}th",
            'type' => 'text',
        ));

        // Category dropdown
        $wp_customize->add_setting("bog_section_{$i}th_category", array(
            'default' => '',
            'sanitize_callback' => 'absint',
        ));
        $wp_customize->add_control(new WP_Customize_Category_Control(
            $wp_customize,
            "bog_section_{$i}th_category",
            array(
                'label' => __('Select Category', 'your_textdomain'),
                'section' => "bog_section_{$i}th",
                'settings' => "bog_section_{$i}th_category",
            )
        ));
    }


    // About Banner Desktop
    $wp_customize->add_setting('about_banner_desktop', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'about_banner_desktop', array(
        'label' => __('About Banner Desktop', 'theme_textdomain'),
        'section' => 'my_about_section',
        'settings' => 'about_banner_desktop',
    )));
    
    // About Banner Mobile
    $wp_customize->add_setting('about_banner_mobile', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'about_banner_mobile', array(
        'label' => __('About Banner Mobile', 'theme_textdomain'),
        'section' => 'my_about_section',
        'settings' => 'about_banner_mobile',
    )));
    
    // Secondary Title
    $wp_customize->add_setting('bg_secondary_title', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('bg_secondary_title', array(
        'label' => __('Secondary Title', 'theme_textdomain'),
        'section' => 'my_about_section',
        'type' => 'text',
    ));
    
    // Secondary Textarea
    $wp_customize->add_setting('bg_secondary_textarea', array(
        'default' => '',
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'bg_secondary_textarea', array(
        'label' => __('Secondary Textarea', 'theme_textdomain'),
        'section' => 'my_about_section',
        'settings' => 'bg_secondary_textarea',
        'type' => 'textarea',
    )));
    
    // Investors Title
    $wp_customize->add_setting('investors_title', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('investors_title', array(
        'label' => __('Investors Title', 'theme_textdomain'),
        'section' => 'my_about_section',
        'type' => 'text',
    ));


    
    // Directors Title
    $wp_customize->add_setting('directors_title', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('directors_title', array(
        'label' => __('Directors Title', 'theme_textdomain'),
        'section' => 'my_about_section',
        'type' => 'text',
    ));
    

    // Publications Fields
    $wp_customize->add_setting('publications_title', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('publications_title', array(
        'label' => __('Publications Title', 'theme_textdomain'),
        'section' => 'my_about_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('publications_description', array(
        'default' => '',
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'publications_description', array(
        'label' => __('Publications Description', 'theme_textdomain'),
        'section' => 'my_about_section',
        'settings' => 'publications_description',
        'type' => 'textarea',
    )));
    
    $wp_customize->add_setting('publications_button_link_1st', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('publications_button_link_1st', array(
        'label' => __('Publications Button Link 1st', 'theme_textdomain'),
        'section' => 'my_about_section',
        'type' => 'url',
    ));
    
    $wp_customize->add_setting('publications_button_text_1st', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('publications_button_text_1st', array(
        'label' => __('Publications Button Text 1st', 'theme_textdomain'),
        'section' => 'my_about_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('publications_button_link_2nd', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('publications_button_link_2nd', array(
        'label' => __('Publications Button Link 2nd', 'theme_textdomain'),
        'section' => 'my_about_section',
        'type' => 'url',
    ));
    
    $wp_customize->add_setting('publications_button_text_2nd', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('publications_button_text_2nd', array(
        'label' => __('Publications Button Text 2nd', 'theme_textdomain'),
        'section' => 'my_about_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('publications_image', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'publications_image', array(
        'label' => __('Publications Image', 'theme_textdomain'),
        'section' => 'my_about_section',
        'settings' => 'publications_image',
    )));
    
    // CSR Fields
    $wp_customize->add_setting('csr_title', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('csr_title', array(
        'label' => __('CSR Title', 'theme_textdomain'),
        'section' => 'my_about_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('csr_description', array(
        'default' => '',
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'csr_description', array(
        'label' => __('CSR Description', 'theme_textdomain'),
        'section' => 'my_about_section',
        'settings' => 'csr_description',
        'type' => 'textarea',
    )));
    
    $wp_customize->add_setting('csr_button_link', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('csr_button_link', array(
        'label' => __('CSR Button Link', 'theme_textdomain'),
        'section' => 'my_about_section',
        'type' => 'url',
    ));
    
    $wp_customize->add_setting('csr_button_text', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('csr_button_text', array(
        'label' => __('CSR Button Text', 'theme_textdomain'),
        'section' => 'my_about_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('csr_image', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'csr_image', array(
        'label' => __('CSR Image', 'theme_textdomain'),
        'section' => 'my_about_section',
        'settings' => 'csr_image',
    )));
    
    // Compliance Fields
    $wp_customize->add_setting('compliance_title', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('compliance_title', array(
        'label' => __('Compliance Title', 'theme_textdomain'),
        'section' => 'my_about_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('compliance_description', array(
        'default' => '',
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'compliance_description', array(
        'label' => __('Compliance Description', 'theme_textdomain'),
        'section' => 'my_about_section',
        'settings' => 'compliance_description',
        'type' => 'textarea',
    )));
    
    $wp_customize->add_setting('compliance_button_link', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('compliance_button_link', array(
        'label' => __('Compliance Button Link', 'theme_textdomain'),
        'section' => 'my_about_section',
        'type' => 'url',
    ));
    
    $wp_customize->add_setting('compliance_button_text', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('compliance_button_text', array(
        'label' => __('Compliance Button Text', 'theme_textdomain'),
        'section' => 'my_about_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('compliance_image', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'compliance_image', array(
        'label' => __('Compliance Image', 'theme_textdomain'),
        'section' => 'my_about_section',
        'settings' => 'compliance_image',
    )));
    
    // Create the custom section
    $wp_customize->add_section('my_about_section', array(
        'title' => __('About Section', 'theme_textdomain'),
        'priority' => 45,
    ));

    
    
}
add_action('customize_register', 'my_theme_customizer_register');
