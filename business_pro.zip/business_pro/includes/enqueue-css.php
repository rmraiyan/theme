<?php

function enqueue_my_styles() {
    // Enqueue Bootstrap CSS
    wp_enqueue_style('bootstrap-css', get_template_directory_uri() . '/assets/lib/bootstrap/css/bootstrap.min5488.css');

    // Enqueue Bootstrap Icons CSS
    wp_enqueue_style('bootstrap-icons-css', get_template_directory_uri() . '/assets/lib/bootstrap-icons/bootstrap-icons.css');

    // Enqueue AOS CSS
    wp_enqueue_style('aos-css', get_template_directory_uri() . '/assets/lib/aos/aos.css');

    // Enqueue Swiper CSS
    wp_enqueue_style('swiper-css', get_template_directory_uri() . '/assets/lib/swiper/swiper-bundle.min.css');

    // Enqueue GLightbox CSS
    wp_enqueue_style('glightbox-css', get_template_directory_uri() . '/assets/lib/glightbox/css/glightbox.min.css');
    // Enqueue slick CSS
    wp_enqueue_style('slick-min-css', get_template_directory_uri() . '/assets/lib/slick-carousel/1.9.0/slick.min.css');
    // Enqueue slick CSS
    wp_enqueue_style('slick-css', get_template_directory_uri() . '/assets/lib/slick-carousel/1.9.0/slick.css');
    

    // Enqueue Website CSS
    wp_enqueue_style('website-css', get_template_directory_uri() . '/css/website.css');
}

add_action('wp_enqueue_scripts', 'enqueue_my_styles');