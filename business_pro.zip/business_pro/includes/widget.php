<?php
// Registering footer widget areas
function theme_register_footer_widget_area() {
    register_sidebar( array(
        'name'          => esc_html__( 'Footer Widget Area First', 'your-theme-textdomain' ),
        'id'            => 'footer-widget-area1',
        'description'   => esc_html__( 'Widgets added here will appear in the footer.', 'your-theme-textdomain' ),
        'before_widget' => '<div id="%1$s" class="footer-logo d-flex align-items-center">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ) );
     register_sidebar( array(
        'name'          => esc_html__( 'Footer Widget Area Second', 'your-theme-textdomain' ),
        'id'            => 'footer-widget-area2',
        'description'   => esc_html__( 'Widgets added here will appear in the footer.', 'your-theme-textdomain' ),
        'before_widget' => '<div id="%1$s" class="col-md-3">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ) );
     register_sidebar( array(
        'name'          => esc_html__( 'Footer Widget Area Third', 'your-theme-textdomain' ),
        'id'            => 'footer-widget-area3',
        'description'   => esc_html__( 'Widgets added here will appear in the footer.', 'your-theme-textdomain' ),
        'before_widget' => '<div id="%1$s" class="col-md-3">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ) );
     register_sidebar( array(
        'name'          => esc_html__( 'Footer Widget Area Fourth', 'your-theme-textdomain' ),
        'id'            => 'footer-widget-area4',
        'description'   => esc_html__( 'Widgets added here will appear in the footer.', 'your-theme-textdomain' ),
        'before_widget' => '<div id="%1$s" class="col-md-6">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ) );
}
add_action( 'widgets_init', 'theme_register_footer_widget_area' );