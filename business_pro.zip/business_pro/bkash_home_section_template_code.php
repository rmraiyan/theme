<section class="py-0">
  <div id="bannerCarouselControls" class="carousel carousel-dark slide carousel-fade" data-bs-ride="carousel">
    <div class="carousel-inner"> <?php
        // Query the 'intro_slider' custom post type
        $args = array(
            'post_type' => 'intro_slider',
            'posts_per_page' => -1, // Retrieve all posts
        );
        $intro_sliders = get_posts($args);

        if ($intro_sliders) {
            $is_first = true; // To add the 'active' class to the first item
            foreach ($intro_sliders as $post) {
                setup_postdata($post);

                // Get custom fields
                $slider_link = get_post_meta($post->ID, '_intro_slider_link', true);
                $mobile_image_id = get_post_meta($post->ID, '_intro_slider_mobile_image', true);
                $mobile_image_url = $mobile_image_id ? wp_get_attachment_image_url($mobile_image_id, 'full') : '';

                // Output the content
                ?> <div class="carousel-item 
        
        
        <?php echo $is_first ? 'active' : ''; ?>" data-bs-interval="5000">
        <!-- Banner for large devices --> <?php
                    // Get featured image for desktop
                    if (has_post_thumbnail($post->ID)) {
                        $desktop_image_url = wp_get_attachment_image_url(get_post_thumbnail_id($post->ID), 'full');
                        ?> <img class="d-none d-md-block object-cover w-100 bg-dark" alt="
          
          
          <?php echo esc_attr(get_the_title()); ?>" width="1920" data-src="
          
          
          <?php echo esc_url($desktop_image_url); ?>" src="
          
          
          <?php echo esc_url($desktop_image_url); ?>" style="aspect-ratio: 1920 / 500"> <?php
                    }
                    ?>
        <!-- Banner for mobile devices --> <?php if ($mobile_image_url): ?> <img class="lazy d-block d-md-none object-cover w-100 aspect-2x1 bg-dark" alt="
            
            
            <?php echo esc_attr(get_the_title()); ?>" width="360" data-src="
            
            
            <?php echo esc_url($mobile_image_url); ?>" src="
            
            
            <?php echo esc_url($mobile_image_url); ?>"> <?php endif; ?> <div class="carousel-content">
          <h2 class="pb-half fw-bold"> <?php the_title(); ?> </h2> <?php if ($slider_link): ?> <a class="btn btn-outline-primary rounded-pill" href="
                
                
                <?php echo esc_url($slider_link); ?>" target="_self"> বিস্তারিত </a> <?php endif; ?>
        </div>
      </div> <?php
                $is_first = false; // Set to false after the first item
            }
            wp_reset_postdata();
        } else {
            echo '
          
          
          <p>No intro sliders found.</p>';
        }
        ?> </div>
    <div class="carousel-indicators mb-1 mb-md-2">
      <button type="button" class="carousel-indicators-control" data-bs-slide="prev">
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12.5 16L5.49932 9.30417L12.5 1.99999" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
        </svg>
      </button> <?php
      // Generate carousel indicators
      foreach ($intro_sliders as $index => $post) {
          echo '
          
          
          <button type="button" data-bs-target="#bannerCarouselControls" data-bs-slide-to="' . $index . '" ' . ($index === 0 ? 'class="active" aria-current="true"' : '') . ' aria-label="Slide ' . $index . '"></button>';
      }
      ?> <button type="button" class="carousel-indicators-control" data-bs-slide="next">
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M5.5 16L12.5007 9.30417L5.5 1.99999" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
        </svg>
      </button>
      <button type="button" data-bs-slide="pause" class="carousel-indicators-control">
        <svg viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M3 2.59286V15.4071C3 16.6517 3.945 17.67 5.1 17.67C6.255 17.67 7.2 16.6517 7.2 15.4071V2.59286C7.2 1.34829 6.255 0.33 5.1 0.33C3.945 0.33 3 1.34829 3 2.59286Z" fill="currentColor"></path>
          <path d="M10.8008 2.59286V15.4071C10.8008 16.6517 11.7458 17.67 12.9008 17.67C14.0558 17.67 15.0008 16.6517 15.0008 15.4071V2.59286C15.0008 1.34829 14.0558 0.330002 12.9008 0.330002C11.7458 0.330002 10.8008 1.34829 10.8008 2.59286Z" fill="currentColor"></path>
        </svg>
      </button>
      <button type="button" data-bs-slide="play" class="carousel-indicators-control d-none">
        <svg viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M4.00171 17.5C3.75225 17.4995 3.5072 17.4251 3.29067 17.2843C2.8031 16.9701 2.5 16.3604 2.5 15.6984V2.3017C2.5 1.63788 2.8031 1.02994 3.29067 0.715814C3.51235 0.570962 3.76419 0.496472 4.01985 0.500128C4.27552 0.503785 4.52562 0.585455 4.74403 0.736602L14.8143 7.59016C15.0242 7.73978 15.1972 7.94755 15.3172 8.19399C15.4371 8.44043 15.5 8.71747 15.5 8.99912C15.5 9.28076 15.4371 9.5578 15.3172 9.80424C15.1972 10.0507 15.0242 10.2585 14.8143 10.4081L4.74241 17.2635C4.5189 17.4171 4.26289 17.4989 4.00171 17.5Z" fill="currentColor"></path>
        </svg>
      </button>
    </div>
  </div>
</section>
<!-- Services Card: Starts -->
<section class="gradient-top-bottom" id="financial-solutions-content">
  <div class="container">
    <h2 class="text-center"> <?php echo esc_html(get_theme_mod('services_card_text_setting')); ?> </h2>
    <div class="row row-cols-2 row-cols-xl-4 g-half g-lg-4"> 
      <?php
        $args = array(
            'post_type' => 'services_card',
            'posts_per_page' => -1, // Retrieve all posts
        );
        $services_cards = get_posts($args);

        if ($services_cards) :
            foreach ($services_cards as $post) :
                setup_postdata($post);
                // Get custom fields
                $link = get_post_meta(get_the_ID(), '_services_card_link', true);
                $image_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
                $title = get_the_title();
                $description = get_the_content();
      ?>
        <div class="col">
            <a href="<?php echo esc_url($link); ?>" class="card shadow-sm h-100 text-center service-card text-body">
                <div class="px-2 pt-1 pt-md-2 pb-1 m-half mx-auto">
                    <img data-src="<?php echo esc_url($image_url); ?>" src="<?php echo esc_url($image_url); ?>" class="img-fluid aspect-1x1" alt="<?php echo esc_attr($title); ?>" width="150">
                </div>
                <div class="card-body pt-0 px-1 mx-half pb-0 mb-half">
                    <h3 class="card-title fw-normal mb-0 mb-md-1"><?php echo esc_html($title); ?></h3>
                    <p class="card-text d-none d-md-block"><?php echo esc_html($description); ?></p>
                </div>
                <div class="card-footer bg-transparent border-0 mb-0 mb-md-half py-1">
                    <p class="mb-0 text-primary"> বিস্তারিত জানুন </p>
                </div>
            </a>
        </div>
        <?php
          endforeach;
            wp_reset_postdata();
          endif;
        ?>
    </div>
    <h4 class="more-service-title title-line position-relative overflow-hidden text-center py-2 py-md-4 mb-0 fw-medium z-1" id="services-content"> <?php echo esc_html(get_theme_mod('services_title_text_setting')); ?> </h4>
    <!-- Service Slider: Starts -->
    <section class="py-0">
      <div class="slider services-slick-slider"> <?php
      // Query the 'service_slider' custom post type
      $args = array(
          'post_type' => 'service_slider',
          'posts_per_page' => -1, // Retrieve all posts
      );
      $service_slider = get_posts($args);

      if ($service_slider) :
          foreach ($service_slider as $post) :
              setup_postdata($post);
              // Get custom fields
              $link = get_post_meta(get_the_ID(), '_service_slider_link', true);
              $image_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
              $text = get_the_title();
    ?> <div class="carousel-item">
          <div class="d-flex justify-content-center my-1" style="width: 100%; display: inline-block;">
            <a href="
                    
                    <?php echo esc_url($link); ?>" class="card align-items-center text-center bg-transparent text-body">
              <img src="
                      
                      <?php echo esc_url($image_url); ?>" class="img-fluid aspect-1x1" width="70" alt="
                      
                      <?php echo esc_attr($text); ?>">
              <div class="card-body pt-1 pt-md-2 pb-0 px-0">
                <h5 class="card-title fw-normal mb-0"> <?php echo esc_html($text); ?> </h5>
              </div>
            </a>
          </div>
        </div> <?php
          endforeach;
          wp_reset_postdata();
      else :
          echo '
                
                <p>No intro sliders found.</p>';
      endif;
    ?> </div>
    </section>
    <!-- Service Slider: Ends -->
  </div>
</section>
<!-- Services Card: End -->
<!-- Static Banner: Starts -->
<section class="pt-4 pb-0 position-relative overflow-hidden" id="bkash-app-content"> <?php
        $background_image_url = get_theme_mod('background_image_setting');
        if ($background_image_url) {
            echo '
        
          
          <img class="img-fluid position-absolute top-0 start-0 bottom-0 end-0 p-0 border-0 m-auto d-block object-cover" alt="Download bKash App" width="1920" src="' . esc_url($background_image_url) . '" style="aspect-ratio: 64 / 19;width:0;height:0;min-width:100%;max-width:100%;min-height:100%;max-height:100%;" />';
        }
    ?> <div class="container">
    <div class="overlay-content text-white">
      <div class="container">
        <div class="row justify-content-center position-relative">
          <div class="col-12 col-md-5 align-self-center text-center text-md-start aos-init aos-animate" data-aos="fade-zoom-in" data-aos-delay="140">
            <h2 class="text-primary pb-1"> <?php echo esc_html(get_theme_mod('bkash_app_content_heading_setting', __('Default Heading', 'mytheme'))); ?> </h2>
            <p class="pb-1 mb-half"> <?php echo esc_html(get_theme_mod('bkash_app_content_description_setting', __('Default description', 'mytheme'))); ?> </p>
            <div class="d-flex flex-wrap justify-content-center justify-content-md-start"> <?php
                $android_app_image_url = get_theme_mod('android_app_image_setting');
                $android_app_link_url = get_theme_mod('android_app_link_setting');
                if ($android_app_image_url) {
                    echo '
                    
                      
                      <a href="' . esc_url($android_app_link_url) . '" class="me-1 text-white mb-md-1 mb-lg-0" aria-label="Get bKash app on Google Play">';
                    echo '
                      
                        
                        <img src="' . esc_url($android_app_image_url) . '" alt="' . esc_attr__('Android App Image', 'mytheme') . '" />';
                    echo '
                    
                      
                      </a>';
                }
                ?> <?php
                $ios_app_image_url = get_theme_mod('ios_app_image_setting');
                $ios_app_link_url = get_theme_mod('ios_app_link_setting');
                if ($ios_app_image_url) {
                    echo '
                    
                      
                      <a href="' . esc_url($ios_app_link_url) . '" class="text-white" aria-label="Get bKash app on App Store">';
                    echo '
                      
                        
                        <img src="' . esc_url($ios_app_image_url) . '" alt="' . esc_attr__('iOS App Image', 'mytheme') . '" />';
                    echo '
                    
                      
                      </a>';
                }
                ?> </div>
          </div>
          <div class="col-12 col-md-5 align-self-end"> <?php
            $static_banner_url = get_theme_mod('static_banner_setting');
            if ($static_banner_url) {
                echo '
                  
                    
                    <img class="img-fluid d-block mx-auto mt-2 mt-md-auto aos-init aos-animate" alt="" width="327" data-aos="slide-up" data-aos-duration="1200" src="' . esc_url($static_banner_url) . '" style="aspect-ratio: 109 / 183"/>';
            }
            ?> </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Static Banner: End -->
<!-- Business Cards: Starts -->
<section id="business-content">
  <div class="container">
    <h2 class="text-center pb-1"><?php echo esc_html(get_theme_mod('business_content_heading')); ?></h2>
    <div class="tinymce-container">
      <div class="tinymce-text text-center pb-0 pb-md-2 mb-half"><?php echo wp_kses_post(get_theme_mod('business_content_description')); ?></div>
    </div>
    <div class="row justify-content-between align-items-center">
      <div class="col-6 d-none d-xl-block">
        <div class="row row-cols-2 row-cols-xl-3 g-1">
<?php
    // Query the 'business_card' custom post type
    $args = array(
        'post_type' => 'business_card',
        'posts_per_page' => -1, // Retrieve all posts
    );
    $business_cards = get_posts($args);

    if ($business_cards) :
        foreach ($business_cards as $post) :
            setup_postdata($post);
            // Get custom fields
            $link = get_post_meta(get_the_ID(), '_business_card_link', true);
            $image_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
            $title = get_the_title();
    ?>
        <div class="col">
            <a href="<?php echo esc_url($link); ?>" target="_blank" class="card shadow-sm p-2 text-center rounded-1 h-100 text-body">
                <img src="<?php echo esc_url($image_url); ?>" class="img-fluid mx-auto aspect-1x1" width="110" alt="<?php echo esc_attr($title); ?>">
                <div class="card-body p-0">
                    <p class="card-title fw-normal mb-0 mt-1"><?php echo esc_html($title); ?></p>
                </div>
            </a>
        </div>
    <?php
        endforeach;
        wp_reset_postdata();
    else :
        echo '<p>No business cards found.</p>';
    endif;
    ?>
        </div>
      </div>
      <div class="col-12 d-block d-xl-none">
<!-- Business Slider: Starts -->
  <section class="py-0">
    <div class="slider services-slick-slider">
      <?php
      // Query the 'business_card' custom post type
      $args = array(
          'post_type' => 'business_card',
          'posts_per_page' => -1, // Retrieve all posts
      );
      $business_card = get_posts($args);

      if ($business_card) :
          foreach ($business_card as $post) :
              setup_postdata($post);
              // Get custom fields
              $link = get_post_meta(get_the_ID(), '_business_card_link', true);
              $image_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
              $text = get_the_title();
      ?> 
      <div class="business-card-carousel carousel-item">
        <div class="d-flex justify-content-center my-1" style="width: 100%; display: inline-block;">
          <a href="<?php echo esc_url($link); ?>" class="card align-items-center text-center bg-transparent text-body">
            <img src="<?php echo esc_url($image_url); ?>" class="img-fluid aspect-1x1" width="70" alt="<?php echo esc_attr($text); ?>">
              <div class="card-body pt-1 pt-md-2 pb-0 px-0">
                <h5 class="card-title fw-normal mb-0"> <?php echo esc_html($text); ?> </h5>
              </div>
          </a>
        </div>
      </div> 
      <?php endforeach;
        wp_reset_postdata();
        else : echo '<p>No intro sliders found.</p>';
        endif;
      ?> 
    </div>
  </section>
<!-- Business Slider: Ends -->
</div>
<div class="col-11 col-md-5 mx-auto">
  <div class="pt-1 pt-md-0 mt-half mt-md-0" style="aspect-ratio: 69 / 50">
                  <?php
                $banner_url = get_theme_mod('business_content_banner');
                if ($banner_url) {
                    echo '<img src="' . esc_url($banner_url) . '" class="img-fluid" alt=" width="552"' . esc_attr__('Business Content Banner', 'mytheme') . '" class="business-content-banner" />';
                }
              ?>
  </div>
</div>
</div>
</div>
</section>
<!-- Business Cards: End -->

<!-- bKash Blogs: Starts -->
<section class="" id="whats-new-content">
  <div class="container ">
    <h2 class="text-center"><?php echo esc_html(get_theme_mod('bKash_blogs_content_heading')); ?></h2>
    <div class="row justify-content-center justify-content-md-start g-1">
      
      <?php
// Custom Query for Home Page to display recent posts
$home_query = new WP_Query(array(
    'post_type' => 'post',
    'posts_per_page' => 3, // Limit the number of posts displayed on the home page
));

if ($home_query->have_posts()) :
    while ($home_query->have_posts()) : $home_query->the_post(); ?>
        <div class="col-11 col-md-4">
            <a href="<?php the_permalink(); ?>" class="card blog-card text-body">
                <div class="aspect-4x3">
                    <?php if (has_post_thumbnail()) : ?>
                        <img src="<?php the_post_thumbnail_url(); ?>" class="card-img-top" alt="<?php the_title(); ?>">
                    <?php endif; ?>
                </div>
                <div class="card-body pb-0">
                    <h5 class="card-title fw-medium lh-sm line-clamp-3 mb-0 mb-md-half">
                        <?php the_title(); ?>
                    </h5>
                </div>
                <div class="card-footer pt-0 pb-1 bg-transparent border-0 fs--1 text-muted">
                    পোস্টের তারিখ <?php echo convert_to_bangla_date(get_the_date()); ?>
                    <span class="px-half">|</span>
                    <?php
                    // Get the "Minute Read" custom field value
                    $minute_read = get_post_meta(get_the_ID(), '_minute_read', true);
                    if ($minute_read) {
                        echo esc_html($minute_read) ; // Display in Bangla
                    }
                    ?>
                </div>
            </a>
        </div>
    <?php endwhile;
    wp_reset_postdata();
else : ?>
    <p><?php esc_html_e('No posts found.'); ?></p>
<?php endif; ?>


      <div class="col-12 text-center pt-1 pt-md-2 mt-half mt-md-0">
        <a href="<?php echo esc_html(get_theme_mod('bKash_blogs_content_button')); ?>" class="btn btn-outline-primary rounded-pill"><?php echo esc_html(get_theme_mod('bKash_blogs_content_button_text')); ?></a>
      </div>
    </div>
  </div>
</section>
<!-- bKash Blogs: Ends -->


<!-- bKash Locator: Starts -->
  <section class="overflow-hidden" id="touchpoints-content">
    <div class="container">
      <h2 class="text-center"><?php echo esc_html(get_theme_mod('bkash_locator_content_heading')); ?></h2>
      <div class="row justify-content-center">
        <div class="col-12 col-md-10">
          <div class="row row-cols-1 row-cols-md-2 g-half g-md-1">

              <?php
// Query the 'bkash_locator' custom post type
$args = array(
    'post_type' => 'bkash_locator',
    'posts_per_page' => -1, // Retrieve all posts
);
$bkash_locator = get_posts($args);

if ($bkash_locator) :
    foreach ($bkash_locator as $post) :
        setup_postdata($post);
        $image_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
        $title = get_the_title();
        $excerpt = get_the_excerpt();
        ?>
      <div class="col aos-init aos-animate" data-aos="fade-right" data-aos-offset="0" data-aos-easing="ease-in-sine" data-aos-duration="1200">
        <a href="<?php the_permalink(); ?>" class="card rounded-1 shadow-sm h-100 text-center text-body">
          <div class="card-body ms-0 mt-0 ms-md-half mt-md-half">
            <h3 class="card-title fw-medium"><?php echo esc_html($title); ?></h3>
            <p class="card-text"><?php echo esc_html($excerpt); ?></p>
          </div>
                      <?php if (has_post_thumbnail()) : ?>
                          <img src="<?php echo esc_url($image_url); ?>"class="img-fluid d-block mx-auto p-half aspect-2x1" width="300" alt="<?php echo esc_attr($title); ?>">
                      <?php endif; ?>
        </a>
      </div>
    <?php
    endforeach;
    wp_reset_postdata();
else :
    echo '<p>No locations found.</p>';
endif;
?>

          </div>
        </div>
      </div>
    </div>
  </section>
<!-- bKash Locator: End -->
<!-- section -->
<section id="board-of-directors-content">
    <div class="container">
      <?php 
      $directors_title = get_theme_mod('directors_title');
      ?>
        <h2 class="title-line position-relative overflow-hidden text-center mb-0 z-1"><?php echo esc_html($directors_title); ?></h2>
        <div class="row justify-content-center pt-2 mt-half">
            <div class="col-12 justify-content-around">
                <div class="row row-cols-2 row-cols-md-3 row-cols-xl-4 gx-3 gx-lg-1 gy-2 justify-content-around justify-content-md-center text-center px-0 px-md-4">

                    <?php

                    // Query for the 'director' custom post type
                    $args = array(
                        'post_type' => 'director',
                        'posts_per_page' => -1,
                    );
                    $directors = new WP_Query($args);

                    // Debugging: Print the number of posts found
                    echo '<!-- Number of Directors: ' . $directors->found_posts . ' -->';

                    if ($directors->have_posts()) : 
                        while ($directors->have_posts()) : $directors->the_post();
                            $image = get_the_post_thumbnail_url(get_the_ID(), 'full');
                            $modal_image = get_the_post_thumbnail_url(get_the_ID(), 'full'); // Use the same featured image for the modal
                            $title = get_post_meta(get_the_ID(), 'custom_title', true); // Retrieve the custom text field for title
                            ?>

                            <div class="col">
                                <a href="#" data-bs-toggle="modal" data-bs-target="#modal-<?php the_ID(); ?>" class="bod-single position-relative d-inline-block text-body">
                                    <img src="<?php echo esc_url($image); ?>" class="rounded-circle img-fluid mb-1 aspect-1x1" alt="" width="175">
                                    <h5 class="mb-0 bod-name"><?php the_title(); ?></h5>
                                </a>
                            </div>

                            <!-- Modal -->
                            <div class="modal fade" id="modal-<?php the_ID(); ?>" tabindex="-1" aria-labelledby="modalLabel-<?php the_ID(); ?>" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered modal-xl">
                                    <div class="modal-content rounded-2 border-0">
                                        <div class="d-flex justify-content-end">
                                            <button type="button" class="btn-close mt-half me-half" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-header justify-content-start mx-1 mx-md-4 px-0">
                                            <img src="<?php echo esc_url($modal_image); ?>" class="lazy" alt="" width="60" height="60">
                                            <div class="text-start ps-1 ps-md-2">
                                                <h5 class="modal-title" id="modalLabel-<?php the_ID(); ?>"><?php the_title(); ?></h5>
                                                <p class="mb-0"><?php echo esc_html($title); ?></p>
                                            </div>
                                        </div>
                                        <div class="modal-body text-start mx-1 mx-md-4 px-0 pb-4">
                                            <p style="text-align: justify;"><?php the_content(); ?></p> <!-- Display excerpt here -->
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php
                        endwhile;
                    else :
                        echo '<p>No directors found.</p>';
                    endif;

                    // Reset post data
                    wp_reset_postdata();
                    ?>

                </div>
            </div>
        </div>
    </div>
</section>
<!-- section -->
<!-- Offer Section: Starts-->
  <section class="gradient-top-bottom pb-2 mb-1" id="offers-content">
    <div class="container">
        <div class="row justify-content-center justify-content-lg-between align-items-center">
          <div class="col-11 col-lg-4 text-center text-lg-start">
            <h2 class="pb-0 pb-md-1"><?php echo esc_html(get_theme_mod('offer_section_content_heading')); ?></h2>
            <p class="pb-half pb-md-2"><?php echo esc_html(get_theme_mod('offer_section_content_dec')); ?></p>
            <a href="<?php echo esc_html(get_theme_mod('offer_section_content_button_url')); ?>" class="btn btn-outline-primary rounded-pill d-none d-lg-inline-block"><?php echo esc_html(get_theme_mod('offer_section_content_button_text')); ?></a>
          </div>
          <div class="col-10 col-lg-7">
            <div class="row gx-half gy-half gy-md-1">
                <?php
                // Query the 'offer_section' custom post type
                $args = array(
                    'post_type' => 'offer_section',
                    'posts_per_page' => -1, // Retrieve all posts
                );
                $offer_section = get_posts($args);

                if ($offer_section) :
                    foreach ($offer_section as $post) :
                        setup_postdata($post);
                        $image_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
                        $title = get_the_title();
                        $excerpt = get_the_excerpt();
                        ?>
                      <div class="three-blog-style col-md">
                        <a href="<?php the_permalink(); ?>" class="card shadow offer-preview-card text-body">
                                      <?php if (has_post_thumbnail()) : ?>
                                          <img src="<?php echo esc_url($image_url); ?>" class="card-img-top aspect-4x3" alt="<?php echo esc_attr($title); ?>">
                                      <?php endif; ?>
                          <div class="card-body">
                            <h5 class="card-title mb-0"><?php echo esc_html($title); ?></h5>
                            <p class="card-text">
                              <small class="text-muted"><?php echo esc_html($excerpt); ?></small>
                            </p>
                          </div>
                        </a>
                      </div>
                    <?php
                    endforeach;
                    wp_reset_postdata();
                else :
                    echo '<p>No offer found.</p>';
                endif;
                ?>
              <div class="col-12 d-block d-md-none text-center pt-1 pt-md-2 mt-half mt-md-0">
                <a href="<?php echo esc_html(get_theme_mod('offer_section_content_button_url')); ?>" class="btn btn-outline-primary rounded-pill"> <?php echo esc_html(get_theme_mod('offer_section_content_button_text')); ?> </a>
              </div>
            </div>
          </div>
        </div>
    </div>
  </section>
<!-- Offer Section: End-->


<section class="gradient-bottom-top pt-2 mt-1 overflow-hidden" id="secure-experience-content">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-md-7">
                <h2 class="text-center"><?php echo esc_html(get_theme_mod('cubic_carousel_content_heading')); ?></h2>
            </div>
        </div>
        <div class="row justify-content-center align-items-center">
            <div class="col-12 col-lg-11">
                <div class="grid gap-half layout" data-box-carousel='{"duration":5000, "onHover":"pause", "pagination":true, "autoplay":true }'>

                    <?php
                      // Query the custom post type
                      $args = array(
                          'post_type' => 'box_carousel',
                          'posts_per_page' => -1, // Get all posts
                      );
                      $box_carousel_query = new WP_Query($args);

                      if ($box_carousel_query->have_posts()) :
                          $counter = 1;
                          while ($box_carousel_query->have_posts()) : $box_carousel_query->the_post();
                              $image_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
                              $active_class = $counter === 1 ? 'active' : '';
                    ?>

                    <!-- Text Section -->
                    <div class="dot-flip grid-area-<?php echo $counter; ?> aos-init aos-animate" data-aos="fade-<?php echo $counter % 2 == 0 ? 'left' : 'right'; ?>" data-aos-offset="0" data-aos-easing="ease-in-sine" data-aos-duration="1200">
                        <div class="d-flex align-items-center flex-md-row-reverse justify-content-md-end flex-lg-row">
                            <div class="box-carousel-nav text-start text-lg-end <?php echo $active_class; ?>" data-carousel-target="#boxCarouselNav<?php echo $counter; ?>">
                                <h3 class="box-carousel-nav-title text-primary cursor-pointer" data-carousel-paginate="<?php echo $counter; ?>" tabindex="0">
                                    <?php the_title(); ?>
                                </h3>
                                <p class="box-carousel-nav-text mb-0">
                                    <?php the_excerpt(); ?>
                                </p>
                            </div>
                            <div class="box-carousel-indicator d-none d-md-block">
                                <div class="box-carousel-dot me-2 mx-lg-2 p-half bg-primary rounded-circle"></div>
                            </div>
                        </div>
                    </div>

                    <?php $counter++; endwhile; ?>

                    <!-- Image Section -->
                    <div class="grid-area-img position-relative featured-image-container" data-carousel-targets="data-carousel-targets">
                        <?php $counter = 1; $box_carousel_query->rewind_posts(); while ($box_carousel_query->have_posts()) : $box_carousel_query->the_post(); 
                              $image_url = get_the_post_thumbnail_url(get_the_ID(), 'full'); 
                              $active_class = $counter === 1 ? 'active' : ''; 
                        ?>
                        <div class="box-slides featured-image <?php echo $active_class; ?>" id="boxCarouselNav<?php echo $counter; ?>">
                            <img class="img-fluid d-block mx-auto" alt="<?php the_title(); ?>" width="308" data-src="<?php echo esc_url($image_url); ?>" src="<?php echo esc_url($image_url); ?>" style="aspect-ratio: 154 / 321">
                        </div>
                        <?php $counter++; endwhile; ?>
                    </div>

                    <?php
                      wp_reset_postdata();
                      else :
                        echo '<p>No carousel items found.</p>';
                      endif;
                    ?>
                    
                </div>
            </div>
        </div>
    </div>
</section>