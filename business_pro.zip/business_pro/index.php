<?php get_header();?>

<?php include(locate_template('bkash_home_section_template_code.php')); ?>

<?php get_footer();?>




