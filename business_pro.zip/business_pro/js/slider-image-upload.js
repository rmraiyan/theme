jQuery(document).ready(function($) {
    $('#slider_image').change(function(e) {
        var input = e.target;
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#slider_image_preview').attr('src', e.target.result);
            };
            reader.readAsDataURL(input.files[0]);
        }
    });
});
