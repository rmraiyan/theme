jQuery(document).ready(function($){
  $('.customize-icon-upload').click(function(e) {
    e.preventDefault();

    var button = $(this),
        custom_uploader = wp.media({
      title: 'Select Icon',
      button: {
        text: 'Use this icon'
      },
      multiple: false
    }).on('select', function() {
      var attachment = custom_uploader.state().get('selection').first().toJSON();
      button.prev('.custom-icon-url').val(attachment.url);
    }).open();
  });
});





