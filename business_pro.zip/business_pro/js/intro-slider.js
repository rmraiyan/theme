jQuery(document).ready(function($){
    var mediaUploader;
    $('.upload-image-button').click(function(e) {
        e.preventDefault();
        var $button = $(this);
        
        if (mediaUploader) {
            mediaUploader.open();
            return;
        }

        mediaUploader = wp.media.frames.file_frame = wp.media({
            title: 'Choose Image',
            button: {
                text: 'Choose Image'
            },
            multiple: false
        });

        mediaUploader.on('select', function() {
            var attachment = mediaUploader.state().get('selection').first().toJSON();
            $button.prev('input').val(attachment.id);
            $button.next('.mobile-image-preview').html('<img src="' + attachment.url + '" style="max-width:100%;" />');
        });

        mediaUploader.open();
    });
});
