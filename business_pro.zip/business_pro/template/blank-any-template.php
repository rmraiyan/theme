<?php
/*
Template Name: Blank Any
*/
get_header(); 
?>
<section class="pb-1">
        <div class="tinymce-container">
            <div class="tinymce-text">
                <!-- Breadcrumb -->
        <div class="pb-1">
          <nav aria-label="breadcrumb">
            <div class="breadcrumb d-block m-0">
              <span class="breadcrumb-item">
                <a href="
										<?php echo esc_url(home_url()) .''; ?>">হোম </a>
              </span>
              <span class="breadcrumb-item active" aria-current="page"> <?php the_title(); ?> </span>
            </div>
          </nav>
        </div>
                                <!-- Breadcrumb Ends -->

                <!-- Page Header -->
                <h2 class="pb-0">যোগাযোগ করুন</h2>
                            </div>
        </div>
</section>

<section class="pt-0">
        <div class="tinymce-container">
            <div class="tinymce-text">
                <div class="tinymce-text"><?php the_content(); ?></div>
            </div>
        </div>
    </section>


<?php get_footer(); ?>