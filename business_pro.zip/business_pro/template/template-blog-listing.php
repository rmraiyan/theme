<?php
/*
Template Name: Blog Listing
*/
get_header(); 

// Handle search and category filters
$search_query = isset($_GET['query']) ? sanitize_text_field($_GET['query']) : '';
$category = isset($_GET['cat']) ? intval($_GET['cat']) : '';
$sort_by = isset($_GET['sort_by']) ? sanitize_text_field($_GET['sort_by']) : 'date_desc';
$desktop_image = get_theme_mod('blog_banner_desktop_image');
$mobile_image = get_theme_mod('blog_banner_mobile_image');

$args = array(
    'post_type' => 'post',
    'posts_per_page' => 5,
    'paged' => get_query_var('paged') ? get_query_var('paged') : 1,
    'orderby' => 'date',
    'order' => ($sort_by == 'date_asc') ? 'ASC' : 'DESC',
);

if (!empty($search_query)) {
    $args['s'] = $search_query;
}

if (!empty($category)) {
    $args['cat'] = $category;
}

$query = new WP_Query($args);

// Determine if filters are applied
$filters_applied = !empty($search_query) || !empty($category);
?>

<!-- Blog Banner with Title: Starts -->
<section class="bg-light py-0">
    <div class="container px-0 px-md-half">
        <div class="blog-banner d-flex align-items-start align-items-md-center overflow-hidden position-relative w-100">
                                    <img src="<?php echo esc_url($desktop_image); ?>" class="d-none d-md-block position-absolute w-100 h-100 object-cover z-1" >

                                    <img src="<?php echo esc_url($mobile_image); ?>" class="d-md-none position-absolute w-100 h-100 object-cover z-1 pe-none">

            <div class="row justify-content-start align-items-center position-relative g-0 py-1 py-md-3 my-half z-2 pe-none">
                <div class="col">
                    <div class="px-1">
                        <h2 class="text-primary pb-0"><?php echo esc_html(get_theme_mod('blog_banner_title', 'বিকাশ ব্লগ')); ?></h2>
                        <h4 class="mb-0"><?php echo esc_html(get_theme_mod('blog_banner_subtitle', 'বিকাশ-এর ব্লগ পড়ুন')); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Blog Banner with Title: Ends -->

<!-- Find Blog: Starts -->
<section class="bg-light py-0" id="blogHomeSearch">
    <div class="container">
        <form method="GET" action="<?php echo esc_url(get_permalink()); ?>">
            <div class="row py-half py-md-1 justify-content-center">
                <div class="col-11 col-md-8 mt-half mb-0 my-md-half">
                    <div class="input-group">
                        <input class="form-control" type="search" placeholder="কীওয়ার্ড দিয়ে খুঁজুন" aria-label="Search by Keyword" aria-describedby="blog-search-btn" id="keyword" name="query" value="<?php echo esc_attr($search_query); ?>" autocomplete="off">
                        <button class="btn px-1 py-0 text-primary" type="submit" id="blog-search-btn" style="border-color: #d8d8d8;">
                            <span class="visually-hidden">খোঁজ করুন</span>
                            <em class="bi bi-search fs-1"></em>
                        </button>
                    </div>
                </div>
                <div class="col-7 col-md-4 col-lg-3 my-md-half">
                    <select id="category" name="cat" class="form-select" onchange="this.form.submit()">
                        <option value=""><?php _e('সকল ক্যাটাগরি'); ?></option>
                        <?php 
                        $categories = get_categories(array(
                            'taxonomy' => 'category',
                            'orderby' => 'name',
                            'order'   => 'ASC',
                        ));
                        foreach ($categories as $cat) {
                            echo '<option value="' . esc_attr($cat->term_id) . '" ' . selected($category, $cat->term_id, false) . '>' . esc_html($cat->name) . '</option>';
                        }
                        ?>
                    </select>
                </div>

            </div>
        </form>
        <?php if ($category || $search_query) : ?>
        <div class="row justify-content-start align-items-center g-1 mt-2">
                        <div class="col-auto">
                <button class="btn btn-outline-white btn-sm loading-disabled" onclick="window.location.href='<?php echo esc_url(get_permalink()); ?>'">
                    ফিল্টার বাদ দিন
                </button>
            </div>
            <?php if ($category) : ?>
            <div class="col-auto">
                <div class="d-flex align-items-center bg-light rounded px-half">
                    <button class="btn btn-sm p-0 me-half shadow-none" onclick="window.location.href='<?php echo esc_url(remove_query_arg('cat')); ?>'">
                        <span class="visually-hidden">Clear Filter</span>
                        <em class="bi bi-x-lg"></em>
                    </button>
                    <?php echo esc_html(get_cat_name($category)); ?>
                </div>
            </div>
            <?php endif; ?>

                            <div class="col-7 col-md-4 col-lg-3">
                    <select id="offer_sort" name="sort_by" class="form-select" onchange="this.form.submit()">
                        <option value="date_desc" <?php echo ($sort_by == 'date_desc') ? 'selected' : ''; ?>>
                            তারিখ (নতুন থেকে পুরাতন)
                        </option>
                        <option value="date_asc" <?php echo ($sort_by == 'date_asc') ? 'selected' : ''; ?>>
                            তারিখ (পুরাতন থেকে নতুন)
                        </option>
                    </select>
                </div>
        </div>
        <?php endif; ?>
    </div>
</section>
<!-- Find Blog: Ends -->

<!-- Featured Blog: Starts -->
<section class="bg-light pt-0 px-half px-md-0">
    <div class="container">
        <div class="row g-1 justify-content-center justify-content-md-start">
        <?php
        if ($query->have_posts()) :
            while ($query->have_posts()) : $query->the_post();
                if ($filters_applied) : ?>
                    <div class="col-12 mb-1 mb-md-2">
                        <a href="<?php the_permalink(); ?>" class="card blog-card-horizontal flex-column flex-md-row shadow rounded-1 text-body">
                            <div class="aspect-4x3 blog-horizontal-img-holder">
                                <?php if (has_post_thumbnail()) : ?>
                                    <img src="<?php the_post_thumbnail_url(); ?>" class="card-img-left w-100 h-100" alt="<?php the_title(); ?>">
                                <?php endif; ?>
                            </div>
                            <div class="d-flex flex-column">
                                <div class="card-body pb-0 mb-0 mb-md-half">
                                    <h5 class="card-title lh-sm text-truncate-lines" style="--lines: 3"><?php the_title(); ?></h5>
                                    <div class="card-text lh-2 d-none d-lg-block"><?php the_excerpt(); ?></div>
                                </div>
                                <div class="card-footer pt-0 pb-1 bg-transparent border-0 fs--1 text-muted">
                                    পোস্টের তারিখ <?php echo get_the_date(); ?>
                                    <span class="px-half">|</span><?php
                    // Get the "Minute Read" custom field value
                    $minute_read = get_post_meta(get_the_ID(), '_minute_read', true);
                    if ($minute_read) {
                        echo esc_html($minute_read) ; // Display in Bangla
                    }
                    ?>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php else : ?>
                    <div class="col-11 col-md-4">
                        <a href="<?php the_permalink(); ?>" class="card blog-card text-body">
                            <div class="aspect-4x3">
                                <?php if (has_post_thumbnail()) : ?>
                                    <img src="<?php the_post_thumbnail_url(); ?>" class="card-img-top" alt="<?php the_title(); ?>">
                                <?php endif; ?>
                            </div>
                            <div class="card-body pb-0">
                                <h5 class="card-title fw-medium lh-sm line-clamp-3 mb-0 mb-md-half">
                                    <?php the_title(); ?>
                                </h5>
                            </div>
                            <div class="card-footer pt-0 pb-1 bg-transparent border-0 fs--1 text-muted">
                                পোস্টের তারিখ <?php echo get_the_date(); ?>
                                <span class="px-half">|</span><?php
                    // Get the "Minute Read" custom field value
                    $minute_read = get_post_meta(get_the_ID(), '_minute_read', true);
                    if ($minute_read) {
                        echo esc_html($minute_read) ; // Display in Bangla
                    }
                    ?>
                            </div>
                        </a>
                    </div>
               
 <?php endif;
            endwhile;
            wp_reset_postdata();
        endif;
        ?>
            </div>
</div>
</section>
<!-- Featured Blog: Ends -->

<!-- Blog section 2nd: Start -->
    <section class="px-half px-md-0">
      <div class="container">
        <div class="d-flex justify-content-center justify-content-md-between align-items-center pb-1">
          <h2 class="pb-0 text-center"><?php echo esc_html(get_theme_mod('bkash_services_title', __('বিকাশ সেবাসমূহ', 'mytheme'))); ?></h2>
          <a href="<?php echo esc_url(get_theme_mod('details_button_link', '#')); ?>" class="btn btn-outline-primary rounded-pill d-none d-md-block">
              <?php echo esc_html(get_theme_mod('details_button_text', __('বিস্তারিত জানুন', 'mytheme'))); ?>
          </a>
        </div>
        <div class="row g-1 justify-content-center justify-content-md-start">
          <?php
          $selected_category = get_theme_mod('bog_section_2nd_category', '');
          $bog_section_2nd = new WP_Query(array(
              'post_type' => 'post',
              'posts_per_page' => 3,
              'cat' => $selected_category,
          ));

          if ($bog_section_2nd->have_posts()) :
              while ($bog_section_2nd->have_posts()) : $bog_section_2nd->the_post(); ?>
                  <div class="col-11 col-md-4">
                      <a href="<?php the_permalink(); ?>" class="card blog-card text-body">
                          <div class="aspect-4x3">
                              <?php if (has_post_thumbnail()) : ?>
                                  <img src="<?php the_post_thumbnail_url(); ?>" class="card-img-top" alt="<?php the_title(); ?>">
                              <?php endif; ?>
                          </div>
                          <div class="card-body pb-0">
                              <h5 class="card-title fw-medium lh-sm line-clamp-3 mb-0 mb-md-half">
                                  <?php the_title(); ?>
                              </h5>
                          </div>
                          <div class="card-footer pt-0 pb-1 bg-transparent border-0 fs--1 text-muted">
                              পোস্টের তারিখ <?php echo convert_to_bangla_date(get_the_date()); ?>
                              <span class="px-half">|</span>
                              <?php
                    // Get the "Minute Read" custom field value
                    $minute_read = get_post_meta(get_the_ID(), '_minute_read', true);
                    if ($minute_read) {
                        echo esc_html($minute_read) ; // Display in Bangla
                    }
                    ?>
                          </div>
                      </a>
                  </div>
              <?php endwhile;
              wp_reset_postdata();
          else : ?>
              <p><?php esc_html_e('No posts found.', 'mytheme'); ?></p>
          <?php endif; ?>

          <div class="col-12 d-md-none text-center mt-2">
            <a href="<?php echo esc_url(get_theme_mod('details_button_link', '#')); ?>" class="btn btn-outline-primary rounded-pill">
                <?php echo esc_html(get_theme_mod('details_button_text', __('বিস্তারিত জানুন', 'mytheme'))); ?>
            </a>
          </div>
        </div>
      </div>
    </section>
<!-- Blog section 2nd: Ends -->


<!-- Blog section 3rd: Start -->
    <section class="bg-light px-half px-md-0">
        <div class="container">
            <div class="d-flex justify-content-center justify-content-md-between align-items-center pb-1">
                <h2 class="pb-0 text-center"><?php echo esc_html(get_theme_mod('bog_section_3rd_app_text', 'বিকাশ অ্যাপ')); ?></h2>
                <a href="<?php echo esc_url(get_theme_mod('bog_section_3rd_detail_link', '#')); ?>" class="btn btn-outline-primary rounded-pill d-none d-md-block"><?php echo esc_html(get_theme_mod('bog_section_3rd_detail_text', 'বিস্তারিত জানুন')); ?></a>
            </div>
            <div class="row g-1 justify-content-center justify-content-md-start">
                <?php
                $category_id = get_theme_mod('bog_section_3rd_category');
                $bog_section_3rd_query = new WP_Query(array(
                    'post_type' => 'post',
                    'posts_per_page' => 3,
                    'cat' => $category_id, // Display posts from the selected category
                ));

                if ($bog_section_3rd_query->have_posts()) :
                    while ($bog_section_3rd_query->have_posts()) : $bog_section_3rd_query->the_post(); ?>
                        <div class="col-11 col-md-4">
                            <a href="<?php the_permalink(); ?>" class="card blog-card text-body">
                                <div class="aspect-4x3">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <img src="<?php the_post_thumbnail_url(); ?>" class="card-img-top" alt="<?php the_title(); ?>">
                                    <?php endif; ?>
                                </div>
                                <div class="card-body pb-0">
                                    <h5 class="card-title fw-medium lh-sm line-clamp-3 mb-0 mb-md-half">
                                        <?php the_title(); ?>
                                    </h5>
                                </div>
                                <div class="card-footer pt-0 pb-1 bg-transparent border-0 fs--1 text-muted">
                                    পোস্টের তারিখ <?php echo get_the_date(); ?>
                                    <span class="px-half">|</span>
                                    <?php
                    // Get the "Minute Read" custom field value
                    $minute_read = get_post_meta(get_the_ID(), '_minute_read', true);
                    if ($minute_read) {
                        echo esc_html($minute_read) ; // Display in Bangla
                    }
                    ?>
                                </div>
                            </a>
                        </div>
                    <?php endwhile;
                    wp_reset_postdata();
                else : ?>
                    <p><?php esc_html_e('No posts found.', 'textdomain'); ?></p>
                <?php endif; ?>
                <div class="col-12 d-md-none text-center mt-2">
                    <a href="<?php echo esc_url(get_theme_mod('bog_section_3rd_detail_link', '#')); ?>" class="btn btn-outline-primary rounded-pill"><?php echo esc_html(get_theme_mod('bog_section_3rd_detail_text', 'বিস্তারিত জানুন')); ?></a>
                </div>
            </div>
        </div>
    </section>
<!-- Blog section 3rd: Ends -->


<?php
$video_id = get_theme_mod('featured_video_id', 'XIkvTKXL2bo');
$banner_image_url = get_theme_mod('banner_image_url', 'https://www.bkash.com/images/blog_app_download_banner.webp');
$banner_link_url = get_theme_mod('banner_link_url', 'https://www.bkash.com/app');
$section_priority = get_theme_mod('featured_video_section_priority', 43);
?>

<section class="px-1 px-md-0" style="order: <?php echo esc_attr($section_priority); ?>;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-11 col-md-9">
                <div class="blogpage-featured-video">
                    <div class="ratio ratio-16x9 overflow-hidden rounded-3" id="player-container">
                        <!-- The YouTube player will be inserted here -->
                    </div>
                </div>
            </div>
            <div class="col-md-3 d-none d-xl-block">
                <a href="<?php echo esc_url($banner_link_url); ?>">
                    <img src="<?php echo esc_url($banner_image_url); ?>" class="img-fluid object-cover rounded-3" alt="Banner" width="256px" style="max-height: 545px;">
                </a>
            </div>
        </div>
    </div>
</section>

<script>
// Load the IFrame Player API code asynchronously.
var tag = document.createElement('script');
tag.src = "https://www.youtube.com/iframe_api";
var firstScriptTag = document.getElementsByTagName('script')[0];
firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

// Replace the 'player-container' div with an <iframe> and YouTube player after the API code downloads.
var player;
function onYouTubeIframeAPIReady() {
    player = new YT.Player('player-container', {
        height: '550',
        width: '100%',
        videoId: '<?php echo esc_js($video_id); ?>',
        playerVars: {
            'autoplay': 0,
            'controls': 1,
            'rel': 0, // Disable related videos at the end
            'modestbranding': 1
        },
        events: {
            'onReady': onPlayerReady
        }
    });
}

function onPlayerReady(event) {
    // You can perform actions when the player is ready if needed
}
</script>






<!-- Blog section 4th: Start -->
    <section class="bg-light px-half px-md-0">
        <div class="container">
            <div class="d-flex justify-content-center justify-content-md-between align-items-center pb-1">
                <h2 class="pb-0 text-center">
                    <?php echo esc_html(get_theme_mod("bog_section_4th_title", 'Default Title')); ?>
                </h2>
                <a href="<?php echo esc_url(get_theme_mod("bog_section_4th_link_url", '#')); ?>" class="btn btn-outline-primary rounded-pill d-none d-md-block">
                    <?php echo esc_html(get_theme_mod("bog_section_4th_link_text", 'বিস্তারিত জানুন')); ?>
                </a>
            </div>
            <div class="row g-1 justify-content-center justify-content-md-start">
                <?php
                // Query for posts from the selected category
                $category_id = get_theme_mod("bog_section_4th_category");
                $bog_section_4th_query = new WP_Query(array(
                    'post_type' => 'post',
                    'posts_per_page' => 3,
                    'cat' => $category_id,
                ));

                if ($bog_section_4th_query->have_posts()) :
                    while ($bog_section_4th_query->have_posts()) : $bog_section_4th_query->the_post(); ?>
                        <div class="col-11 col-md-4">
                            <a href="<?php the_permalink(); ?>" class="card blog-card text-body">
                                <div class="aspect-4x3">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <img src="<?php the_post_thumbnail_url(); ?>" class="card-img-top" alt="<?php the_title(); ?>">
                                    <?php endif; ?>
                                </div>
                                <div class="card-body pb-0">
                                    <h5 class="card-title fw-medium lh-sm line-clamp-3 mb-0 mb-md-half">
                                        <?php the_title(); ?>
                                    </h5>
                                </div>
                                <div class="card-footer pt-0 pb-1 bg-transparent border-0 fs--1 text-muted">
                                    পোস্টের তারিখ <?php echo get_the_date(); ?>
                                    <span class="px-half">|</span>
                                    <?php
                    // Get the "Minute Read" custom field value
                    $minute_read = get_post_meta(get_the_ID(), '_minute_read', true);
                    if ($minute_read) {
                        echo esc_html($minute_read) ; // Display in Bangla
                    }
                    ?>
                                </div>
                            </a>
                        </div>
                    <?php endwhile;
                    wp_reset_postdata();
                else : ?>
                    <p><?php esc_html_e('No posts found.', 'your_textdomain'); ?></p>
                <?php endif; ?>
            </div>
            <div class="col-12 d-md-none text-center mt-2">
                <a href="<?php echo esc_url(get_theme_mod("bog_section_4th_link_url", '#')); ?>" class="btn btn-outline-primary rounded-pill">
                    <?php echo esc_html(get_theme_mod("bog_section_4th_link_text", 'বিস্তারিত জানুন')); ?>
                </a>
            </div>
        </div>
    </section>
<!-- Blog section 4th: Ends -->

<!-- Blog section 5th: Start -->
    <section class="bg-light px-half px-md-0">
        <div class="container">
            <div class="d-flex justify-content-center justify-content-md-between align-items-center pb-1">
                <h2 class="pb-0 text-center">
                    <?php echo esc_html(get_theme_mod("bog_section_5th_title", 'Default Title')); ?>
                </h2>
                <a href="<?php echo esc_url(get_theme_mod("bog_section_5th_link_url", '#')); ?>" class="btn btn-outline-primary rounded-pill d-none d-md-block">
                    <?php echo esc_html(get_theme_mod("bog_section_5th_link_text", 'বিস্তারিত জানুন')); ?>
                </a>
            </div>
            <div class="row g-1 justify-content-center justify-content-md-start">
                <?php
                // Query for posts from the selected category
                $category_id = get_theme_mod("bog_section_5th_category");
                $bog_section_5th_query = new WP_Query(array(
                    'post_type' => 'post',
                    'posts_per_page' => 3,
                    'cat' => $category_id,
                ));

                if ($bog_section_5th_query->have_posts()) :
                    while ($bog_section_5th_query->have_posts()) : $bog_section_5th_query->the_post(); ?>
                        <div class="col-11 col-md-4">
                            <a href="<?php the_permalink(); ?>" class="card blog-card text-body">
                                <div class="aspect-4x3">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <img src="<?php the_post_thumbnail_url(); ?>" class="card-img-top" alt="<?php the_title(); ?>">
                                    <?php endif; ?>
                                </div>
                                <div class="card-body pb-0">
                                    <h5 class="card-title fw-medium lh-sm line-clamp-3 mb-0 mb-md-half">
                                        <?php the_title(); ?>
                                    </h5>
                                </div>
                                <div class="card-footer pt-0 pb-1 bg-transparent border-0 fs--1 text-muted">
                                    পোস্টের তারিখ <?php echo get_the_date(); ?>
                                    <span class="px-half">|</span>
                                    <?php
                    // Get the "Minute Read" custom field value
                    $minute_read = get_post_meta(get_the_ID(), '_minute_read', true);
                    if ($minute_read) {
                        echo esc_html($minute_read) ; // Display in Bangla
                    }
                    ?>
                                </div>
                            </a>
                        </div>
                    <?php endwhile;
                    wp_reset_postdata();
                else : ?>
                    <p><?php esc_html_e('No posts found.', 'your_textdomain'); ?></p>
                <?php endif; ?>
            </div>
            <div class="col-12 d-md-none text-center mt-2">
                <a href="<?php echo esc_url(get_theme_mod("bog_section_5th_link_url", '#')); ?>" class="btn btn-outline-primary rounded-pill">
                    <?php echo esc_html(get_theme_mod("bog_section_5th_link_text", 'বিস্তারিত জানুন')); ?>
                </a>
            </div>
        </div>
    </section>
<!-- Blog section 5th: Ends -->

<?php get_footer(); ?>