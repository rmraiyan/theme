<?php
/*
Template Name: About Section
*/
get_header(); 

// Retrieve settings from Customizer
$about_banner_desktop = get_theme_mod('about_banner_desktop');
$about_banner_mobile = get_theme_mod('about_banner_mobile');
$bg_secondary_title = get_theme_mod('bg_secondary_title');
$bg_secondary_textarea = get_theme_mod('bg_secondary_textarea');
$investors_title = get_theme_mod('investors_title');

$directors_title = get_theme_mod('directors_title');

$publications_title = get_theme_mod('publications_title');
$publications_description = get_theme_mod('publications_description');
$publications_button_link_1st = get_theme_mod('publications_button_link_1st');
$publications_button_text_1st = get_theme_mod('publications_button_text_1st');
$publications_button_link_2nd = get_theme_mod('publications_button_link_2nd');
$publications_button_text_2nd = get_theme_mod('publications_button_text_2nd');
$publications_image = get_theme_mod('publications_image');
$csr_title = get_theme_mod('csr_title');
$csr_description = get_theme_mod('csr_description');
$csr_button_link = get_theme_mod('csr_button_link');
$csr_button_text = get_theme_mod('csr_button_text');
$csr_image = get_theme_mod('csr_image');
$compliance_title = get_theme_mod('compliance_title');
$compliance_description = get_theme_mod('compliance_description');
$compliance_button_link = get_theme_mod('compliance_button_link');
$compliance_button_text = get_theme_mod('compliance_button_text');
$compliance_image = get_theme_mod('compliance_image');
?>

<section class="py-0">
  <!-- Banner for large devices -->
  <?php if ($about_banner_desktop): ?>
    <img src="<?php echo esc_url($about_banner_desktop); ?>" alt="About Banner Desktop" class="d-none d-md-block object-cover w-100 bg-dark" style="aspect-ratio: 1920 / 500;">
  <?php endif; ?>

  <!-- Banner for mobile devices -->
  <?php if ($about_banner_mobile): ?>
    <img src="<?php echo esc_url($about_banner_mobile); ?>" alt="About Banner Mobile" class="lazy d-block d-md-none object-cover w-100 aspect-2x1 bg-dark" width="360">
  <?php endif; ?>
</section>

<section class="bg-secondary">
<?php if ($bg_secondary_title || $bg_secondary_textarea): ?>
        <div class="tinymce-container">
        <?php if ($bg_secondary_title): ?>
            <h2 class="text-center"><?php echo esc_html($bg_secondary_title); ?></h2>
            <?php endif; ?>
            <?php if ($bg_secondary_textarea): ?>
            <div class="tinymce-text">
                <p style="text-align:justify;"><?php echo wp_kses_post($bg_secondary_textarea); ?></p>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
</section>


<section class="pb-1" id="partners-content">
        <div class="container">
            <h2 class="text-center"><?php echo esc_html($investors_title); ?></h2>
            <div class="row row-cols-3 row-cols-md-auto justify-content-center text-center gx-2 gx-md-4 gy-1">

              <?php
                    // Query for the 'brand' custom post type
                    $args = array(
                        'post_type' => 'brand',
                        'posts_per_page' => -1,
                    );
                    $brands = new WP_Query($args);

                    if ($brands->have_posts()) : 
                        while ($brands->have_posts()) : $brands->the_post();
                            $image = get_the_post_thumbnail_url(get_the_ID(), 'full'); // Get the featured image
                            ?>

                            <div class="col">
                                <img src="<?php echo esc_url($image); ?>" class="aspect-1x1 img-fluid" width="122" alt="<?php the_title(); ?>">
                            </div>

                        <?php
                        endwhile;
                    else :
                        echo '<p>No brands found.</p>';
                    endif;

                    // Reset post data
                    wp_reset_postdata();
                    ?>
                
            </div>
        </div>
    </section>




<section id="board-of-directors-content">
    <div class="container">
        <h2 class="title-line position-relative overflow-hidden text-center mb-0 z-1"><?php echo esc_html($directors_title); ?></h2>
        <div class="row justify-content-center pt-2 mt-half">
            <div class="col-12 justify-content-around">
                <div class="row row-cols-2 row-cols-md-3 row-cols-xl-4 gx-3 gx-lg-1 gy-2 justify-content-around justify-content-md-center text-center px-0 px-md-4">

                    <?php
                    // Query for the 'director' custom post type
                    $args = array(
                        'post_type' => 'director',
                        'posts_per_page' => -1,
                    );
                    $directors = new WP_Query($args);

                    // Debugging: Print the number of posts found
                    echo '<!-- Number of Directors: ' . $directors->found_posts . ' -->';

                    if ($directors->have_posts()) : 
                        while ($directors->have_posts()) : $directors->the_post();
                            $image = get_the_post_thumbnail_url(get_the_ID(), 'full');
                            $modal_image = get_the_post_thumbnail_url(get_the_ID(), 'full'); // Use the same featured image for the modal
                            $title = get_post_meta(get_the_ID(), 'custom_title', true); // Retrieve the custom text field for title
                            ?>

                            <div class="col">
                                <a href="#" data-bs-toggle="modal" data-bs-target="#modal-<?php the_ID(); ?>" class="bod-single position-relative d-inline-block text-body">
                                    <img src="<?php echo esc_url($image); ?>" class="rounded-circle img-fluid mb-1 aspect-1x1" alt="" width="175">
                                    <h5 class="mb-0 bod-name"><?php the_title(); ?></h5>
                                </a>
                            </div>

                            <!-- Modal -->
                            <div class="modal fade" id="modal-<?php the_ID(); ?>" tabindex="-1" aria-labelledby="modalLabel-<?php the_ID(); ?>" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered modal-xl">
                                    <div class="modal-content rounded-2 border-0">
                                        <div class="d-flex justify-content-end">
                                            <button type="button" class="btn-close mt-half me-half" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-header justify-content-start mx-1 mx-md-4 px-0">
                                            <img src="<?php echo esc_url($modal_image); ?>" class="lazy" alt="" width="60" height="60">
                                            <div class="text-start ps-1 ps-md-2">
                                                <h5 class="modal-title" id="modalLabel-<?php the_ID(); ?>"><?php the_title(); ?></h5>
                                                <p class="mb-0"><?php echo esc_html($title); ?></p>
                                            </div>
                                        </div>
                                        <div class="modal-body text-start mx-1 mx-md-4 px-0 pb-4">
                                            <p style="text-align: justify;"><?php the_content(); ?></p> <!-- Display excerpt here -->
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php
                        endwhile;
                    else :
                        echo '<p>No directors found.</p>';
                    endif;

                    // Reset post data
                    wp_reset_postdata();
                    ?>

                </div>
            </div>
        </div>
    </div>
</section>





<section class="bg-secondary">
        <div class="container">
            <div class="row justify-content-center align-items-center gy-2 gy-md-0 gx-0 gx-md-2">
                <div class="col-10 col-lg-5 text-center text-md-start">
                    <h2 class="pb-1 mb-0"><?php echo esc_html($publications_title); ?></h2>
                    <p class="fs-1 text-dark pb-2"><?php echo wp_kses_post($publications_description); ?>
                    </p>
                    <div class="row justify-content-around justify-content-md-start g-1">
                        <div class="col-8 col-md-5">
                            <a href="<?php echo esc_url($publications_button_link_1st); ?>" class="btn btn-outline-primary rounded-pill w-100 px-0"><?php echo esc_html($publications_button_text_1st); ?></a>
                        </div>
                        <div class="col-8 col-md-5">
                            <a href="<?php echo esc_url($publications_button_link_2nd); ?>" class="btn btn-outline-primary rounded-pill w-100 px-0"><?php echo esc_html($publications_button_text_2nd); ?></a>
                        </div>
                    </div>
                </div>
                <div class="col-auto">
                    <img data-src="<?php echo esc_url($publications_image); ?>" src="<?php echo esc_url($publications_image); ?>" class="img-fluid" alt="" width="400" style="aspect-ratio: 10 / 9">
                </div>
            </div>
        </div>
    </section>

<section>
        <div class="container">
            <div class="row justify-content-center align-items-center gy-2 gy-md-0 gx-0 gx-md-2">
                <div class="col-10 col-lg-5 text-center text-md-start">
                    <h2 class="pb-1 mb-0"><?php echo esc_html($csr_title); ?></h2>
                    <p class="fs-1 text-dark pb-2"><?php echo wp_kses_post($csr_description); ?>
                    </p>
                    <a href="<?php echo esc_url($csr_button_link); ?>" class="btn btn-outline-primary rounded-pill"><?php echo esc_html($csr_button_text); ?></a>
                </div>
                <div class="col-auto order-md-first">
                    <img data-src="<?php echo esc_url($csr_image); ?>" src="<?php echo esc_url($csr_image); ?>" class="img-fluid" alt="" width="400" style="aspect-ratio: 10 / 9">
                </div>
            </div>
        </div>
    </section>


    <section class="bg-secondary">
        <div class="container">
            <div class="row justify-content-center align-items-center gy-2 gy-md-0 gx-0 gx-md-2">
                <div class="col-10 col-lg-5 text-center text-md-start">
                    <h2 class="pb-1 mb-0"><?php echo esc_html($compliance_title); ?></h2>
                    <p class="fs-1 text-dark pb-2"><?php echo wp_kses_post($compliance_description); ?>
                    </p>
                    <a href="<?php echo esc_url($compliance_button_link); ?>" class="btn btn-outline-primary rounded-pill"><?php echo esc_html($compliance_button_text); ?></a>
                </div>
                <div class="col-auto">
                    <img data-src="<?php echo esc_url($compliance_image); ?>" src="<?php echo esc_url($compliance_image); ?>" class="img-fluid" alt="" width="400" style="aspect-ratio: 10 / 9">
                </div>
            </div>
        </div>
    </section>
<?php get_footer(); ?>
