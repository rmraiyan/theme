<!DOCTYPE html>
<html lang="bn-BD">

<head>    
    <meta charset="utf-8">
    <meta name="google" content="notranslate">
    <link rel="icon" href="https://www.bkash.com/images/favicon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="theme-color" content="#e2136e">
    <meta name="msapplication-navbutton-color" content="#e2136e">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="csrf-token" content="314Ri41RG1FkXZGNsmqeGzn0CB5IycMTzIdrRNnO">

    <!-- SEO -->
    <title>বিকাশ</title>
    <meta name="title" content="bKash | It's that simple">
    <meta name="keywords" content="">
    <meta name="description" content="bKash is the fastest and safest medium of financial transaction, bKash makes your life simple with Send Money, Add Money, Pay Bill, Mobile Recharge, Payment and many more services.">

    <meta name="twitter:image" content="https://www.bkash.com/images/social-share/bKash-social-share-logo-bn.jpg">
    <meta property="og:image" content="https://www.bkash.com/images/social-share/bKash-social-share-logo-bn.jpg">

    <meta property="fb:app_id" content="739494473240208">
    <!-- SEO Ends-->
    <!-- Slick Slider CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css">

<!-- Slick Slider JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>


    <link rel="preload" href="/css/font.3dac4c372f1bacef0ac6cfa595db8a35.css" as="style">
    <link rel="stylesheet" href="/css/font.3dac4c372f1bacef0ac6cfa595db8a35.css">
    <link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
    
    <link rel="preconnect" href="https://cdnjs.cloudflare.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.9.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="/css/website.4849848f5872523f66df1f7ae7f52d00.css">


    <?php wp_head();?>
    
        
</head>
<nav class="navbar navbar-expand-xl sticky-top navbar-dark bg-primary py-0 justify-content-sm-center">
    <div class="container mx-half mx-md-auto py-half py-xl-0">

               <a class="navbar-brand py-0" href="<?php echo esc_url(home_url()) .''; ?>">
            <?php
            $logo_svg_url = get_theme_mod('logo_svg_setting');
            if ($logo_svg_url) {
                echo '<img src="' . esc_url($logo_svg_url) . '" alt="' . esc_attr__('Logo', 'mytheme') . '" class="d-block top-nav-logo" />';
            }
            ?>
        </a>

        <!-- Landmarks -->
<div class="landmark">
    <div class="landmark-body">
        <a href="#top-menu-0" class="landmark-link d-none d-xl-block">
            নেভিগেশন-এ চলে যান
        </a>
        <a href="#offcanvasToggler" class="landmark-link d-block d-xl-none">
            নেভিগেশন-এ চলে যান
        </a>
        <a href="#main-content" class="landmark-link">
            মূল কনটেন্টে চলে যান
        </a>
        <button id="open-live-chat" class="landmark-link">
            লাইভ চ্যাট
        </button>

        <!-- Home -->
                    <a href="#financial-solutions-content" class="landmark-link">
                আর্থিক সল্যুশন
            </a>
            <a href="#services-content" class="landmark-link">
                সার্ভিস
            </a>
            <a href="#bkash-app-content" class="landmark-link">
                বিকাশ অ্যাপ
            </a>
            <a href="#business-content" class="landmark-link">
                ব্যবসায়িক সল্যুশন
            </a>
            <a href="#whats-new-content" class="landmark-link">
                নতুন কি আছে
            </a>
            <a href="#touchpoints-content" class="landmark-link">
                বিকাশ পয়েন্ট
            </a>
            <a href="#offers-content" class="landmark-link">
                অফার
            </a>
            <a href="#secure-experience-content" class="landmark-link">
                নিরাপদ লেনদেন
            </a>
        
        <!-- Campaigns -->
        
        <!-- Campaigns:Search -->
        
        <!-- Service -->
        
        <!-- Business -->
        
        <!-- Help -->
        
        <!-- Help:Locator -->
        


        <!-- Career -->
        
        <!-- About -->
        
        <!-- Blog -->
        
        <!-- BulkOffer:Search -->
        
        <a href="#footer-content" class="landmark-link">
            ফুটার-এ চলে যান
        </a>
    </div>
</div>
        <button class="navbar-toggler border-0 p-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="navbar-toggler" id="offcanvasToggler">
            <span class="small">মেন্যু</span>
            <span class="d-inline-block">
                <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" fill="currentColor" class="bi bi-list fs-2" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"></path>
                </svg>
            </span>
        </button>

        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar">
            <!-- Sidebar Header -->
            <div class="offcanvas-header px-2">
                <button type="button" class="btn-close p-0" data-bs-dismiss="offcanvas" aria-label="বন্ধ করুন"></button>
                                    <svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="70" viewBox="0 0 122 54">
                        <title>bKash Logo</title>
                        <g fill="#E2136E">
                            <path d="m82.9 25.9 3.3 14.6 21.5-10.7zM89 3.8 83.2 25l24 3.8zM62.8.6l25.5 3.1-6 21.8zM62.5 4.8h3l8 10.3zM108.4 29.6l-7.5-10.3 12-2.3zM107.2 32.5l.7-2.2-18.7 9.6zM82.4 26.3 86.3 44l-11.6 9.4zM111.8 22.3h7l-5.1-5.1z"></path>
                        </g>
                        <path fill="#E2136E" d="M5.4 21.2h15.2v2.2H5.2v17.8s-.7-.1-1.1-.1c-.4 0-.9.1-.9.1V21.1c0-5.2 2-8.2 7-8.5 4.5-.3 8 2.3 10.4 3.6v2.6l-.3.1c-.4-1-5.8-5.5-9.3-5.1-3.6.4-5.8 2.9-5.8 6.2 0 0 0 .9.2 1.2z"></path>
                        <path fill="#171717" d="M36.6 24.9c3.8-.1 5.7 1.2 5.8 4.1.1 1.6-.6 3.1-1.7 4.4l-1.9.1v-.3c.7-.2 2.3-1.3 2.2-3.3s-1.6-3.6-4-3.5c0 0-.4 0-.6.1l.2-1.6z"></path>
                        <path fill="#E2136E" d="M18.5 23h2.1v18.2l-2.1-.7z"></path>
                        <path fill="#171717" d="M57.3 25.5c-.8-2.7-3.1-4.3-4.8-4.3H48v2.2h3c1.3 0 2.6-.1 3.8 1 .5.5.7 1 .9 1.7.4 1.7-.4 3.8-2.4 3.8-.6 0-1.3 0-1.9-.2v.1c.5.6.8 1.4 1.2 2.1 1.2-.2 2.4-.9 3.2-1.7 1.1-1.3 1.8-2.9 1.5-4.7"></path>
                        <path fill="#171717" d="M60.6 21.5c-1.3.2-3.3 1.3-4 4.1-.2 1.8.3 3.4 1.5 4.6.7.8 1.8 1.5 2.8 1.7.3-.7.7-1.4 1.1-2.1l-.1-.1c-.5.2-1.1.2-1.7.2-2.1-.1-2.4-2.2-2.1-3.8.3-1.4 1.5-2.8 2.8-2.9 1.4-.1 3.1 1 3.4 2.5.2.8.2 1.6.2 2.4v13.2s.6-.1 1-.1 1 .1 1 .1V21.4h-2.2v2.2c0-.1.1-.1 0-.3-.7-1.3-2.5-2-3.7-1.8M47.6 21.2v20s-.6-.1-1-.1-1 .1-1 .1V23.4H21.1v-2.2h26.5z"></path>
                        <path fill="#E2136E" d="M20.6 41.2h-.3c-7.8 0-12.2-4.3-12.2-8.6 0-3.6 3.3-7.8 10.9-7.8l1.3 1c-5.3 0-9.6 3.4-9.6 6.8 0 3 3.8 7.8 9.9 7.8v.8z"></path>
                        <path fill="#171717" d="M34.8 23h2.1v18.2l-2.1-.7z"></path>
                        <path fill="#171717" d="M36.9 41.2h-.3c-7.8 0-12.2-4.3-12.2-8.6 0-3.6 3.3-7.8 10.9-7.8l1.3 1c-5.3 0-9.6 3.4-9.6 6.8 0 3 3.8 7.8 9.9 7.8v.8z"></path>
                    </svg>
                            </div>

            <div class="offcanvas-body px-2 px-xl-0 justify-content-start justify-content-md-between" id="navigation-content">

              
                     <?php
                        wp_nav_menu(array(
                            'theme_location' => 'primary-menu',
                            'menu_class' => 'primary-menu',
                        ));
                    ?>

                <ul class="navbar-nav justify-content-end flex-grow-1 align-items-stretch align-items-xl-center">
                    <li class="nav-item d-none d-xl-block ms-1 me-1">
                        <button onclick="location.href='<?php echo esc_html(get_theme_mod('header_button_link_setting')); ?>';" class="btn btn-sm btn-outline-light rounded-pill text-nowrap px-2 top-nav-app-btn" id="top-menu-bkash-app"><?php echo esc_html(get_theme_mod('header_button_text_setting')); ?></button>
                    </li>
                    <li class="nav-item d-none d-xl-block text-nowrap ms-1">
                        <a href="<?php echo esc_html(get_theme_mod('header_button_link_eng')); ?>" class="btn btn-sm rounded-pill shadow-none text-white lang-switcher lang-switcher-en en-lang"><?php echo esc_html(get_theme_mod('header_button_text_eng')); ?></a>
                        
    
    <span class="text-white">|</span>

            <a href="<?php echo esc_html(get_theme_mod('header_button_link_bng')); ?>" class="btn btn-sm rounded-pill shadow-none text-white lang-switcher lang-switcher-en en-lang"><?php echo esc_html(get_theme_mod('header_button_text_bng')); ?></a>
                        </li>
                </ul>

                <div class="d-flex d-xl-none flex-column align-items-center mt-3">
                                        
    <a href="https://www.bkash.com/app" class="btn btn-outline-primary btn-sm rounded-pill shadow-sm px-2">বিকাশ অ্যাপ</a>

    <div class="d-flex mt-1 language-switcher">
                                                <button class="btn btn-sm px-half rounded-pill shadow-none fs-0 lang-switcher lang-switcher-en " type="button">
                    <svg id="eng_reg" data-name="English Regular" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18.45 11.09" height="16"><title>English</title>
    <g opacity="0.78">
        <path d="M244.84,186.29h-3.51v3.05h4.1v.9h-5.25v-8.53h5.19v.91h-4v2.76h3.51Z" transform="translate(-240.18 -181.71)" fill="currentColor"></path>
        <path d="M247.67,183.9l.08.95a2.32,2.32,0,0,1,.8-.79,2.16,2.16,0,0,1,1.08-.27,2.06,2.06,0,0,1,1.59.6,2.59,2.59,0,0,1,.57,1.85v4h-1.16v-4a1.75,1.75,0,0,0-.33-1.19,1.34,1.34,0,0,0-1-.35,1.73,1.73,0,0,0-.91.22,1.62,1.62,0,0,0-.59.6v4.7h-1.15V183.9Z" transform="translate(-240.18 -181.71)" fill="currentColor"></path>
        <path d="M253.26,187.19a4.22,4.22,0,0,1,.65-2.47,2.09,2.09,0,0,1,1.82-.93,2.21,2.21,0,0,1,1.06.24,2,2,0,0,1,.77.7l.14-.83h.92v6.38a2.4,2.4,0,0,1-.71,1.87,2.92,2.92,0,0,1-2,.65,4.52,4.52,0,0,1-1-.12,3.91,3.91,0,0,1-.93-.35l.17-.89a3.64,3.64,0,0,0,.81.28,4.22,4.22,0,0,0,.93.11,1.68,1.68,0,0,0,1.22-.38,1.59,1.59,0,0,0,.39-1.17v-.72a2.17,2.17,0,0,1-.75.6,2.23,2.23,0,0,1-1,.21,2.17,2.17,0,0,1-1.81-.85,3.46,3.46,0,0,1-.65-2.21Zm1.15.12a2.72,2.72,0,0,0,.39,1.54,1.38,1.38,0,0,0,1.22.58,1.53,1.53,0,0,0,.87-.24,1.82,1.82,0,0,0,.58-.67V185.6a1.79,1.79,0,0,0-.58-.64,1.52,1.52,0,0,0-.86-.24,1.31,1.31,0,0,0-1.22.69,3.48,3.48,0,0,0-.4,1.78Z" transform="translate(-240.18 -181.71)" fill="currentColor"></path>
    </g>
</svg>                </button>
                        <span class="fs-0 px-half">|</span>
                            <button class="btn btn-sm px-half rounded-pill shadow-none fs-0 lang-switcher lang-switcher-bn text-primary" type="button">
                    <svg id="ban_bold" data-name="Bangla Bold" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 25.82 10.65" height="16"><title>Bengali</title>
    <path d="M244.74,183.7v7.41l-.54-.76-.15-.35h0l-.17-.32c0-.06-.06-.1-.09-.15l-.08-.15h0a3.86,3.86,0,0,0-.28-.4,3.71,3.71,0,0,0-.26-.28,2.08,2.08,0,0,0-.3-.26c-.13-.09-.29-.19-.47-.29l-.2-.11-.25-.13h0l-.25-.11-.19-.11a3.12,3.12,0,0,0-.44-.09,2.32,2.32,0,0,0-.46,0l-1-1.37.92-.63.87-.52,1.22-.59.57-.25.63-.2v-.33h-4.67l-.85-.88h6.94l.85.88Zm-.86,1.62c-.24.08-.47.18-.71.28s-.47.23-.71.36h0l-.65.39-.1.07-.08.05-.09.05-.11.07.37.19.36.22a4.86,4.86,0,0,1,.41.27l.38.31.46.45.22.25a3,3,0,0,1,.24.32Z" transform="translate(-238.18 -181.25)" fill="currentColor" stroke="currentColor" stroke-miterlimit="10" stroke-width="0.15"></path>
    <path d="M249.11,183.7h-1.68v7.45l-.84-.88V185a.78.78,0,0,0,0-.29.86.86,0,0,0-.14-.4,1.29,1.29,0,0,0-.19-.21,2.76,2.76,0,0,0-.25-.21,1.1,1.1,0,0,0-.59-.18h-.21l-.9-.88h.49l.28,0h.21a1.77,1.77,0,0,1,.67.13l.18.1.14.11h0a2,2,0,0,1,.48.7l0,.08-.11-.78,0-.84V182c0-.05,0-.12,0-.22s0-.2-.06-.31l.49.39.07.39,0,.21.06.14.16.2,0,0h.85Z" transform="translate(-238.18 -181.25)" fill="currentColor" stroke="currentColor" stroke-miterlimit="10" stroke-width="0.15"></path>
    <path d="M251.7,186.09a1.64,1.64,0,0,1-.44.33,1.06,1.06,0,0,1-.52.13,1.58,1.58,0,0,1-1.15-.59,2.07,2.07,0,0,1-.49-1.3,1.52,1.52,0,0,1,.11-.6,1.23,1.23,0,0,1,.38-.49h0a1.51,1.51,0,0,1,1-.36,1.47,1.47,0,0,1,1.12.51h0a1.69,1.69,0,0,1,.37.57,1.72,1.72,0,0,1,.11.64,1.58,1.58,0,0,1,0,.32,1,1,0,0,1-.08.29h0A1.62,1.62,0,0,1,251.7,186.09Zm.74,4.7-1.14-.93-.35-.27-.36-.28a9.89,9.89,0,0,0-1.24-.85v-1.83l.88.78h0l.26.22.62.6.46.5.91,1.07.92,1.1v.83Zm-1.57-5.37a1.56,1.56,0,0,0,.39-.35.75.75,0,0,0,.13-.34v0a.23.23,0,0,0-.06-.16.59.59,0,0,0-.17-.13l-.24-.08a1.07,1.07,0,0,0-.25,0,.74.74,0,0,0-.54.16,1.06,1.06,0,0,0-.32.8c0,.29.11.44.33.44a1,1,0,0,0,.32-.08,2.15,2.15,0,0,0,.41-.25Z" transform="translate(-238.18 -181.25)" fill="currentColor" stroke="currentColor" stroke-miterlimit="10" stroke-width="0.15"></path>
    <path d="M261,183.7h-1.58V191l-.9-.82v-3.91a.74.74,0,0,0-.11-.3.58.58,0,0,0-.22-.31l-.1-.07h0a1,1,0,0,0-.47-.14.42.42,0,0,0-.29.2l-.07.2a.66.66,0,0,1,0,.14v.15l.06.4-.44.16-.12-.3-.05-.09a2.28,2.28,0,0,0-.18-.32.78.78,0,0,0-.19-.21,1.49,1.49,0,0,0-.68-.31h0l-.3-.06a1.19,1.19,0,0,0-.69.25,1.31,1.31,0,0,0-.43.68h0l0,.28a.87.87,0,0,0,.06.32.75.75,0,0,0,.18.28h0a1.41,1.41,0,0,0,.44.23,1.09,1.09,0,0,1-.11-.42.77.77,0,0,1,.28-.59.83.83,0,0,1,.59-.25.87.87,0,0,1,.8.56c.05.17.08.3.11.4s0,.19.06.29l0,.15a1,1,0,0,1-.45.55,1.42,1.42,0,0,1-.71.19,2.2,2.2,0,0,1-.61-.09l-.27-.1-.21-.09a2.72,2.72,0,0,1-.38-.31,2.81,2.81,0,0,1-.35-.45,2.07,2.07,0,0,1-.22-1l0-.47a2.25,2.25,0,0,1,.21-.65,2.06,2.06,0,0,1,.36-.5,1.63,1.63,0,0,1,.47-.32,1.2,1.2,0,0,1,.52-.12,2,2,0,0,1,1,.27l.37.3.15.2a2.22,2.22,0,0,1,.15-.23,1.52,1.52,0,0,1,.22-.22,1.44,1.44,0,0,1,.25-.18.73.73,0,0,1,.25-.1,1,1,0,0,1,.72.25l.28.39.13.19.06.12V183.7h-5.7l-.88-.88h8.12Z" transform="translate(-238.18 -181.25)" fill="currentColor" stroke="currentColor" stroke-miterlimit="10" stroke-width="0.15"></path>
    <path d="M263.82,183.7h-1.68v7.45l-.84-.88V185a1.12,1.12,0,0,0,0-.29,1,1,0,0,0-.15-.4,1.29,1.29,0,0,0-.19-.21,1.84,1.84,0,0,0-.25-.21,1.1,1.1,0,0,0-.59-.18h-.21l-.89-.88h.48l.28,0H260a1.77,1.77,0,0,1,.67.13l.19.1.14.11h0a2,2,0,0,1,.48.7l0,.08-.11-.78-.05-.84V182c0-.05,0-.12,0-.22a2.1,2.1,0,0,0-.06-.31l.5.39.06.39,0,.21.07.14.15.2,0,0H263Z" transform="translate(-238.18 -181.25)" fill="currentColor" stroke="currentColor" stroke-miterlimit="10" stroke-width="0.15"></path>
</svg>                </button>
                        </div>
</div>

            </div>
        </div>
    </div>
</nav>