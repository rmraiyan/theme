<?php get_header(); ?>

<!-- Blogpost Body: Starts -->
<section>
    <div class="tinymce-container">
        <div class="row gx-3">
            <div class="col-12 col-lg-8">
                <!-- Featured Image with Caption -->
                <figure class="figure mb-1">
                    <?php if (has_post_thumbnail()) : ?>
                        <img src="<?php the_post_thumbnail_url(); ?>" class="w-100 mb-half aspect-2x1" alt="<?php echo esc_attr(get_the_post_thumbnail_caption()); ?>">
                        <figcaption class="figure-caption fst-italic"><?php echo esc_html(get_the_post_thumbnail_caption()); ?></figcaption>
                    <?php endif; ?>
                </figure>

                <!-- Blog Post Header: Starts -->
                <!-- Breadcrumb: Starts -->
                <div class="pb-1">
                    <nav aria-label="breadcrumb">
                        <div class="breadcrumb d-block m-0">
                            <span class="breadcrumb-item"><a href="<?php echo esc_url(home_url()) .'/blog'; ?>">ব্লগ</a></span>
                            <span class="breadcrumb-item active" aria-current="page"><?php the_title(); ?></span>
                        </div>
                    </nav>
                </div>
                <!-- Breadcrumb: Ends -->

                <h2 class="pb-half"><?php the_title(); ?></h2>
                <div class="mb-2 pb-half">
                    <p class="fs-2 fw-bold text-dark mb-half"><?php the_author(); ?></p>
                    <p class="fs-1 text-grey mb-0"><?php echo convert_to_bangla_date(get_the_date()); ?> <span class="px-half">|</span> 
                    <?php
                        $minute_read = get_post_meta(get_the_ID(), '_minute_read', true);
                        if ($minute_read) {
                            echo esc_html($minute_read);
                        }
                    ?></p>
                </div>
                <!-- Blog Post Header: Ends -->

                <div class="tinymce-text mb-1 pb-half mb-md-2 pb-md-half">
                    <?php the_content(); ?>
                </div>

                <!-- Social Share Buttons -->
                <div>
                    <h5 class="mb-1 fw-medium">আর্টিকেল শেয়ার করুন</h5>
                    <ul class="list-inline">
                        <li class="list-inline-item me-0">
    <button class="btn rounded-1 custom-tooltip text-primary p-0" onclick="copyToClipboard()" onmouseleave="resetTooltipText()">

        
        <img src="https://www.bkash.com/images/icon-copy.svg" id="copy-url-to-clipboard-tooltip" alt="Copy Link" height="42" class="aspect-1x1">
    </button>
</li>

<script>
function copyToClipboard() {
    // Create a temporary input element
    var tempInput = document.createElement("input");
    // Set its value to the current page URL
    tempInput.value = window.location.href;
    // Append it to the body
    document.body.appendChild(tempInput);
    // Select the input's content
    tempInput.select();
    // Copy the selected content to the clipboard
    document.execCommand("copy");
    // Remove the temporary input
    document.body.removeChild(tempInput);
    
    // Update the tooltip text to indicate success
    var tooltip = document.getElementById("copy-url-to-clipboard-tooltip");
    tooltip.innerHTML = "কপি হয়েছে!";
}

function resetTooltipText() {
    // Reset the tooltip text when the user moves the mouse away
    var tooltip = document.getElementById("copy-url-to-clipboard-tooltip");
    tooltip.innerHTML = "লিংক কপি করুন";
}
</script>

                        <li class="list-inline-item mx-2 mx-md-3">
                            <a class="d-inline-block" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" target="_blank">
                                <img src="https://www.bkash.com/images/icon-fb-color.svg" alt="Facebook share" height="42" class="aspect-1x1">
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a class="d-inline-block" href="https://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>" target="_blank">
                                <img src="https://www.bkash.com/images/icon-ln-color.svg" alt="Linkedin share" height="42" class="aspect-1x1">
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Blog Sidebar: Starts -->
            <div class="col-12 col-lg-4 mt-3 mt-md-4 mt-lg-0">
                <!-- Latest Article: Starts -->
                <div class="d-flex justify-content-md-between align-items-center mb-1 pb-half">
                    <h3 class="mb-0 fw-medium">সর্বশেষ আর্টিকেলসমূহ</h3>
                    <a href="<?php echo esc_url(home_url('/blog')); ?>" class="btn btn-link d-none d-md-block d-lg-none">বিস্তারিত জানুন</a>
                </div>
                <div class="row row-cols-1 row-cols-md-3 row-cols-lg-1 g-2">
                    <?php
                    $latest_query = new WP_Query(array(
                        'post_type' => 'post',
                        'posts_per_page' => 3,
                    ));

                    if ($latest_query->have_posts()) :
                        while ($latest_query->have_posts()) : $latest_query->the_post(); ?>
                            <div class="col">
                                <a href="<?php the_permalink(); ?>" class="card blog-card text-body">
                                    <div class="aspect-4x3">
                                        <?php if (has_post_thumbnail()) : ?>
                                            <img src="<?php the_post_thumbnail_url(); ?>" class="card-img-top" alt="<?php the_title(); ?>">
                                        <?php endif; ?>
                                    </div>
                                    <div class="card-body pb-0">
                                        <h5 class="card-title fw-medium lh-sm line-clamp-3 mb-0 mb-md-half"><?php the_title(); ?></h5>
                                    </div>
                                    <div class="card-footer pt-0 pb-1 bg-transparent border-0 fs--1 text-muted">
                                        পোস্টের তারিখ <?php echo convert_to_bangla_date(get_the_date()); ?> <span class="px-half">|</span>
                                        <?php
                                        $minute_read = get_post_meta(get_the_ID(), '_minute_read', true);
                                        if ($minute_read) {
                                            echo esc_html($minute_read);
                                        }
                                        ?>
                                    </div>
                                </a>
                            </div>
                        <?php endwhile;
                        wp_reset_postdata();
                    else : ?>
                        <p><?php esc_html_e('No posts found.'); ?></p>
                    <?php endif; ?>
                    <div class="col text-center">
                        <a href="<?php echo esc_url(home_url('/blog')); ?>" class="btn btn-link d-block d-md-none d-lg-block">বিস্তারিত জানুন</a>
                    </div>
                </div>
                <!-- Latest Article: Ends -->
            </div>
            <!-- Blog Sidebar: Ends -->
        </div>
    </div>
</section>
<!-- Blogpost Body: Ends -->

<?php get_footer(); ?>
